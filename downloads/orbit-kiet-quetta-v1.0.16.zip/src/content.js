(() => {
  if (window.__orbitKietLoadedV11) return;
  window.__orbitKietLoadedV11 = true;

  const state = {
    tab: "attendance",
    minimized: localStorage.getItem("orbit-kiet-minimized") === "1",
    loading: false,
    scheduleLoading: false,
    error: "",
    scheduleError: "",
    data: null,
    schedule: [],
    expanded: new Set(),
    history: null,
    historyLoading: false,
    historyError: "",
    pendingListScrollTop: null,
    pendingSubjectIndex: null
  };

  const aliases = {
    courseId: new Set(["courseid","course_id"]),
    courseCompId: new Set(["coursecompid","coursecomponentid","coursecomp","componentid","course_component_id"]),
    studentId: new Set(["studentid","student_id"]),
    sessionId: new Set(["sessionid","session_id"]),
    code: new Set(["coursecode","subjectcode","subjectid","code","courseid"]),
    name: new Set(["coursename","coursedescription","subjectname","subject","course","name"]),
    component: new Set(["component","componentname","componenttype","coursetype","type"]),
    faculty: new Set(["faculty","facultyname","teacher","teachername","instructor"]),
    present: new Set(["present","presentcount","numberofpresent","presentlecture","presentlectures","presentperiods","classespresent","classesattended","attended","attendedclasses","attendedlectures"]),
    total: new Set(["total","totalcount","numberofperiods","totalclasses","totallecture","totallectures","totalperiods","classestotal","classesconducted","conducted","conductedclasses"]),
    presentTotal: new Set(["presenttotal","attendancetotal","lecturecount","lectures"]),
    percentage: new Set(["percentage","attendancepercentage","attendancepercent","percent","attendance","presentpercentage","presentpercentagewith"]),
    overall: new Set(["overallattendance","overallattendancepercentage","overallattendancepercent","overallpercentage","totalattendancepercentage"]),
    status: new Set(["status","attendancestatus"])
  };

  const clean = v => String(v ?? "").replace(/\s+/g, " ").trim();
  const normKey = v => clean(v).replace(/[^a-z0-9]/gi, "").toLowerCase();
  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  const get = (obj, names) => {
    for (const [k,v] of Object.entries(obj || {})) {
      if (names.has(normKey(k))) return v;
    }
  };
  const num = v => {
    const m = clean(v).match(/-?\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : undefined;
  };
  const pct = v => {
    const n = num(v);
    return n == null ? undefined : Math.max(0, Math.min(100, n));
  };

  function extractSubjects(payload) {
    const out = [], seen = new WeakSet();
    let discoveredStudentId = null;
    let discoveredSessionId = null;

    function walk(v, inherited = {code:"", name:"", courseId:null, courseCompId:null, studentId:null, sessionId:null}) {
      if (Array.isArray(v)) return v.forEach(x => walk(x, inherited));
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const own = {
        code: clean(get(v, aliases.code)),
        name: clean(get(v, aliases.name)),
        courseId: get(v, aliases.courseId),
        courseCompId: get(v, aliases.courseCompId),
        studentId: get(v, aliases.studentId),
        sessionId: get(v, aliases.sessionId)
      };

      const id = {
        code: own.code || inherited.code,
        name: own.name || inherited.name,
        courseId: own.courseId ?? inherited.courseId,
        courseCompId: own.courseCompId ?? inherited.courseCompId,
        studentId: own.studentId ?? inherited.studentId,
        sessionId: own.sessionId ?? inherited.sessionId
      };

      if (id.studentId != null && discoveredStudentId == null) discoveredStudentId = id.studentId;
      if (id.sessionId !== undefined && discoveredSessionId == null) discoveredSessionId = id.sessionId;

      const component = clean(get(v, aliases.component));
      const present = num(get(v, aliases.present));
      const total = num(get(v, aliases.total));
      const explicit = pct(get(v, aliases.percentage));
      const pairText = clean(get(v, aliases.presentTotal));
      const pair = pairText.match(/(\d+(?:\.\d+)?)\s*(?:\/|of)\s*(\d+(?:\.\d+)?)/i);
      const p = present ?? (pair ? Number(pair[1]) : undefined);
      const t = total ?? (pair ? Number(pair[2]) : undefined);
      const percentage = explicit ?? (p != null && t > 0 ? Math.round((p/t)*100) : undefined);

      if ((id.code || id.name) && (component || percentage != null)) {
        out.push({
          courseCode: id.code,
          courseName: id.name,
          courseId: id.courseId != null ? Number(id.courseId) : undefined,
          courseCompId: id.courseCompId != null ? Number(id.courseCompId) : undefined,
          studentId: id.studentId != null ? Number(id.studentId) : undefined,
          sessionId: id.sessionId ?? null,
          component,
          faculty: clean(get(v, aliases.faculty)),
          present: p,
          total: t,
          percentage: percentage ?? 0,
          status: clean(get(v, aliases.status))
        });
      }
      Object.values(v).forEach(x => walk(x, id));
    }
    walk(payload);

    const uniq = new Map();
    for (const s of out) {
      const k = [s.courseCode,s.courseName,s.component,s.present,s.total,s.percentage,s.courseId,s.courseCompId].join("|").toLowerCase();
      if (!uniq.has(k)) uniq.set(k, s);
    }

    // Some CyberVidya payloads keep course identifiers in a sibling object
    // instead of the exact object containing the percentage. Fill those IDs
    // from every discovered course object before returning the subjects.
    const idMap = new Map();
    for (const s of out) {
      if (s.courseId == null && s.courseCompId == null) continue;
      const keys = [historyNorm(s.courseCode), historyNorm(s.courseName)].filter(Boolean);
      for (const key of keys) {
        if (!idMap.has(key)) idMap.set(key, {courseId:s.courseId, courseCompId:s.courseCompId, studentId:s.studentId, sessionId:s.sessionId});
      }
    }
    const subjects = [...uniq.values()].map(s => {
      const extra = idMap.get(historyNorm(s.courseCode)) || idMap.get(historyNorm(s.courseName));
      if (extra) {
        if (s.courseId == null) s.courseId = extra.courseId;
        if (s.courseCompId == null) s.courseCompId = extra.courseCompId;
        if (s.studentId == null) s.studentId = extra.studentId;
        if (s.sessionId == null && extra.sessionId !== undefined) s.sessionId = extra.sessionId;
      }
      return s;
    });
    return { subjects, studentId: discoveredStudentId, sessionId: discoveredSessionId };
  }

  function pageOverall() {
    const m = (document.body?.innerText || "").match(/Overall\s*Attendance[^0-9%]*(\d+(?:\.\d+)?)\s*%/i);
    return m ? pct(m[1]) : undefined;
  }
  function weightedOverall(subjects) {
    const valid = subjects.filter(s => Number.isFinite(s.present) && Number.isFinite(s.total) && s.total > 0);
    const total = valid.reduce((a,s)=>a+s.total,0);
    const present = valid.reduce((a,s)=>a+s.present,0);
    return total ? Math.round(present/total*100) : undefined;
  }

  const dateKey = d => {
    const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0"), day=String(d.getDate()).padStart(2,"0");
    return `${y}-${m}-${day}`;
  };
  const parseDate = value => {
    if (value == null) return null;
    const raw = clean(value);

    // CyberVidya currently returns values like:
    // "17/08/2026 12:30:00"
    const localMatch = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (localMatch) {
      const [, dd, mm, yyyy, hh = "0", min = "0", ss = "0"] = localMatch;
      const d = new Date(
        Number(yyyy),
        Number(mm) - 1,
        Number(dd),
        Number(hh),
        Number(min),
        Number(ss)
      );
      return Number.isNaN(d.getTime()) ? null : d;
    }

    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const formatDay = d => new Intl.DateTimeFormat(undefined, {weekday:"short", month:"short", day:"numeric"}).format(d);
  const formatTime = d => new Intl.DateTimeFormat(undefined, {hour:"numeric", minute:"2-digit"}).format(d);

  function weekBounds(base) {
    const start = new Date(base);
    start.setHours(0,0,0,0);
    start.setDate(start.getDate() - start.getDay());
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return { start: dateKey(start), end: dateKey(end) };
  }

  function extractSchedule(payload) {
    const records = [];
    const seen = new WeakSet();

    function walk(v) {
      if (Array.isArray(v)) return v.forEach(walk);
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const start = parseDate(v.start ?? v.startTime ?? v.dateTime);
      const end = parseDate(v.end ?? v.endTime);
      const type = clean(v.type).toUpperCase();
      const title = clean(v.courseName ?? v.titleFullName ?? v.title ?? v.contentFullName ?? v.content);
      const code = clean(v.courseCode);
      const faculty = clean(v.facultyName);
      const room = clean(v.classRoom ?? v.content);

      const statusRaw = clean(
        v.attendanceStatus ??
        v.attendanceState ??
        v.classAttendanceStatus ??
        v.statusText ??
        v.attendance ??
        v.presence ??
        v.attendanceMarked
      ).toLowerCase();

      const presentFlag =
        v.isPresent === true ||
        v.present === true ||
        v.markedPresent === true ||
        v.attendanceMarked === true && /present|green|attended/i.test(statusRaw);

      const absentFlag =
        v.isAbsent === true ||
        v.absent === true ||
        v.markedAbsent === true ||
        /absent|not present|red/i.test(statusRaw);

      const attendanceStatus =
        presentFlag ? "present" :
        absentFlag ? "absent" :
        /present|attended|green/i.test(statusRaw) ? "present" :
        /absent|not present|red/i.test(statusRaw) ? "absent" :
        null;

      if (start && title && (type === "" || type === "CLASS" || code)) {
        records.push({
          start,
          end,
          title,
          code,
          faculty,
          room,
          variant: clean(v.courseCompVariant),
          type,
          attendanceStatus
        });
      }

      Object.values(v).forEach(walk);
    }
    walk(payload);

    const uniq = new Map();
    for (const r of records) {
      const key = [r.start.toISOString(), r.end?.toISOString() || "", r.title, r.code, r.room].join("|");
      if (!uniq.has(key)) uniq.set(key, r);
    }
    return [...uniq.values()].sort((a,b)=>a.start-b.start);
  }

  function classesNextDays(schedule, days = 4) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const end = new Date(today);
    end.setDate(end.getDate() + days - 1);
    end.setHours(23,59,59,999);
    return schedule.filter(r => r.start >= today && r.start <= end);
  }

  function tone(p) {
    if (p >= 75) return "good";
    if (p >= 65) return "warn";
    return "bad";
  }

  function attendancePlan(subject) {
    const present = Number(subject.present);
    const total = Number(subject.total);

    if (!Number.isFinite(present) || !Number.isFinite(total) || total <= 0) {
      return { kind: "unknown", text: "Attendance count unavailable" };
    }

    if (present / total >= 0.75) {
      const canMiss = Math.max(0, Math.floor((present / 0.75) - total + 1e-9));
      return {
        kind: "safe",
        text: canMiss === 1
          ? "You can miss 1 class and stay ≥75%"
          : `You can miss ${canMiss} classes and stay ≥75%`
      };
    }

    const needAttend = Math.max(0, Math.ceil(3 * total - 4 * present - 1e-9));
    return {
      kind: "need",
      text: needAttend === 1
        ? "Attend 1 more class to reach 75%"
        : `Attend ${needAttend} more classes to reach 75%`
    };
  }

  function escapeHtml(s) {
    return clean(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }


  const historySleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const historyNorm = value => String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  function findHistoryCourseRow(subject) {
    const code = historyNorm(subject?.courseCode);
    const name = historyNorm(subject?.courseName);
    const codeCompact = code.replace(/[^a-z0-9]/g, "");
    const nameWords = name.split(/\s+/).filter(w => w.length >= 3);

    const visible = el => {
      if (!el || el === document.body || el === document.documentElement) return false;
      const r = el.getBoundingClientRect?.();
      if (!r) return true;
      const cs = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && cs.display !== "none" && cs.visibility !== "hidden";
    };

    const matchesText = el => {
      if (!el || el.closest?.("#orbit-kiet-root")) return false;
      const x = historyNorm(el.innerText || el.textContent || "");
      if (!x) return false;
      if (code && (x.includes(code) || x.replace(/[^a-z0-9]/g, "").includes(codeCompact))) return true;
      if (name && x.includes(name)) return true;
      if (nameWords.length >= 2) {
        const hits = nameWords.filter(w => x.includes(w)).length;
        return hits >= Math.min(3, nameWords.length);
      }
      return false;
    };

    const controlBlob = el => [
      el?.getAttribute?.("title") || "",
      el?.getAttribute?.("aria-label") || "",
      el?.getAttribute?.("data-original-title") || "",
      el?.getAttribute?.("data-tooltip") || "",
      typeof el?.className === "string" ? el.className : (el?.className?.baseVal || ""),
      el?.textContent || ""
    ].join(" ").toLowerCase();

    const isEyeControl = el => {
      const b = controlBlob(el);
      return /(^|[\s_-])(eye|view|details?|attendance)([\s_-]|$)/.test(b) ||
        /fa-eye|visibility|visibility_outlined|icon-eye|eye-icon/.test(b);
    };

    const getControls = el => [...(el?.querySelectorAll?.(
      'button,a,[role="button"],i,svg,[onclick],[title],[aria-label],[data-toggle],[data-target]'
    ) || [])].filter(visible);

    const hasEye = el => getControls(el).some(isEyeControl);

    // First find a small text-bearing element for the course. Then walk up
    // through the mobile card/table structure. Quetta's responsive layout
    // does not always use <tr>, and the eye icon may be on a sibling rather
    // than inside the exact text element.
    const all = [...document.querySelectorAll("body *")]
      .filter(el => !el.closest?.("#orbit-kiet-root") && visible(el));

    const leaves = all.filter(el => el.children.length === 0 && matchesText(el));
    const exact = all.filter(el => {
      const x = historyNorm(el.innerText || el.textContent || "");
      return (code && x === code) || (name && x === name);
    });
    const candidates = [...new Set([...exact, ...leaves])];

    // Strongest match: nearest ancestor containing an actual eye/view control.
    for (const start of candidates) {
      let el = start;
      for (let depth = 0; el && depth < 14; depth++, el = el.parentElement) {
        if (hasEye(el)) return el;
      }
    }

    // Next: nearest compact container with controls. This handles cases
    // where the icon has no useful title/aria-label (common on mobile).
    for (const start of candidates) {
      let el = start?.parentElement;
      for (let depth = 0; el && depth < 12; depth++, el = el.parentElement) {
        if (el.closest?.("#orbit-kiet-root")) break;
        const text = historyNorm(el.innerText || el.textContent || "");
        const controls = getControls(el);
        if (text.length <= 1200 && controls.length >= 1) return el;
      }
    }

    // Desktop/table fallback.
    const rows = [...document.querySelectorAll('tr,[role="row"]')].filter(visible);
    const row = rows.find(matchesText);
    if (row) return row;

    return null;
  }

  function findHistoryEye(row) {
    const controls = [...(row?.querySelectorAll?.(
      'button,a,[role="button"],i,svg,[onclick],[title],[aria-label],[data-toggle],[data-target]'
    ) || [])];

    const blob = el => [
      el?.getAttribute?.("title") || "",
      el?.getAttribute?.("aria-label") || "",
      el?.getAttribute?.("data-original-title") || "",
      el?.getAttribute?.("data-tooltip") || "",
      typeof el?.className === "string" ? el.className : (el?.className?.baseVal || ""),
      el?.textContent || ""
    ].join(" ").toLowerCase();

    const eye = controls.find(el => {
      const b = blob(el);
      return /(^|[\s_-])(eye|view|details?|attendance)([\s_-]|$)/.test(b) ||
        /fa-eye|visibility|visibility_outlined|icon-eye|eye-icon/.test(b) ||
        el.matches?.("i.fa-eye,i.fas.fa-eye,i.far.fa-eye,svg[data-icon='eye']");
    });
    if (eye) return eye;

    // Quetta sometimes renders the eye as an unlabelled icon. Prefer the
    // last clickable control in the compact course container; on CyberVidya
    // this is the details/attendance action, while the other controls are
    // course text/navigation elements.
    const clickable = controls.filter(el => {
      const tag = String(el.tagName || "").toLowerCase();
      return ["button","a","i","svg"].includes(tag) || el.getAttribute?.("role") === "button" || el.hasAttribute?.("onclick");
    });
    return clickable[clickable.length - 1] || null;
  }

  function findOfficialHistoryModal(){
    const cs=[...document.querySelectorAll('[role="dialog"],.modal,[class*="modal"],[class*="dialog"]')];
    return cs.find(el=>{const x=historyNorm(el.innerText||'');return x.includes('lecture wise attendance')||x.includes('lecture-wise attendance')||(x.includes('date')&&x.includes('time slot')&&x.includes('attendance'));})||null;
  }
  function parseOfficialHistoryModal(modal){
    const out=[]; const rows=[...modal.querySelectorAll('table tbody tr'),...modal.querySelectorAll('[role="row"]')];
    for(const row of rows){const cells=[...row.querySelectorAll('td,[role="cell"]')].map(c=>String(c.innerText||'').replace(/\s+/g,' ').trim()); if(cells.length<4) continue; const joined=cells.join(' ').toLowerCase(); if(joined.includes('date')&&joined.includes('attendance')) continue; const si=cells.findIndex(c=>/present|absent/i.test(c)); if(si<0) continue; out.push({date:cells[1]||cells[0]||'',day:cells[2]||'',time:cells[3]||'',lectureType:cells[4]||'',attendance:String(cells[si]||'').toUpperCase()});}
    return out;
  }
  function closeOfficialHistoryModal(modal){
    const cs=[...(modal?.querySelectorAll('button,[role="button"],[title],[aria-label]')||[])];
    const close=cs.find(el=>{const b=[el.getAttribute?.('title')||'',el.getAttribute?.('aria-label')||'',el.textContent||'',el.className?.baseVal||el.className||''].join(' ').toLowerCase();return /close/.test(b)||String(el.textContent||'').trim()==='×';});
    try{close?.click();}catch{}
  }
  function parseHistoryPayload(payload){
    const out = [], seen = new WeakSet();
    function walk(v){
      if (Array.isArray(v)) return v.forEach(walk);
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const startRaw = v.start ?? v.startTime ?? v.dateTime ?? v.lectureDate ?? v.attendanceDate;
      const endRaw = v.end ?? v.endTime;
      const start = parseDate(startRaw);
      const end = parseDate(endRaw);
      const attendance = clean(v.attendance ?? v.attendanceStatus ?? v.status ?? v.presence);

      if (start && attendance && /present|absent|attended|not present/i.test(attendance)) {
        out.push({
          date: new Intl.DateTimeFormat(undefined,{day:"2-digit",month:"2-digit",year:"numeric"}).format(start),
          day: new Intl.DateTimeFormat(undefined,{weekday:"long"}).format(start).toUpperCase(),
          time: `${formatTime(start)}${end ? ` - ${formatTime(end)}` : ""}`,
          lectureType: clean(v.lectureType ?? v.type),
          attendance: attendance.toUpperCase()
        });
      }
      Object.values(v).forEach(walk);
    }
    walk(payload);

    const uniq = new Map();
    for (const r of out) {
      const k=[r.date,r.day,r.time,r.attendance].join("|");
      if(!uniq.has(k)) uniq.set(k,r);
    }
    return [...uniq.values()];
  }

  async function readHistoryDirectly(subject) {
    // Use CyberVidya's own eye action instead of reproducing its POST request.
    // This is important on Quetta because the portal can apply additional
    // session/request state that a hand-built fetch does not reproduce.
    const root=document.getElementById('orbit-kiet-root');
    if(root) root.style.display='none';
    try {
      const row=findHistoryCourseRow(subject);
      if(!row) throw new Error(`Could not find the CyberVidya row for ${subject.courseCode||subject.courseName}.`);
      const eye=findHistoryEye(row);
      if(!eye) throw new Error("Could not find CyberVidya's lecture-history eye button.");

      eye.dispatchEvent(new MouseEvent("click", {bubbles:true,cancelable:true,view:window}));
      let modal=null;
      for(let i=0;i<60;i++){
        await historySleep(200);
        modal=findOfficialHistoryModal();
        if(modal) break;
      }
      if(!modal) throw new Error('CyberVidya did not open the lecture-history modal.');

      await historySleep(250);
      let records=parseOfficialHistoryModal(modal);
      if(!records.length){
        await historySleep(700);
        records=parseOfficialHistoryModal(modal);
      }
      closeOfficialHistoryModal(modal);
      return records;
    } finally {
      if(root) root.style.display='';
    }
  }

  function restoreSubjectListPosition() {
    if (state.pendingListScrollTop == null && state.pendingSubjectIndex == null) return;

    requestAnimationFrame(() => {
      const list = document.querySelector("#orbit-kiet-root .orbit-list");
      if (!list) {
        state.pendingListScrollTop = null;
        state.pendingSubjectIndex = null;
        return;
      }

      if (state.pendingListScrollTop != null) {
        list.scrollTop = state.pendingListScrollTop;
      }

      if (state.pendingSubjectIndex != null) {
        const subject = list.querySelector(
          `[data-subject-index="${state.pendingSubjectIndex}"]`
        );

        if (subject) {
          const top = subject.offsetTop;
          const bottom = top + subject.offsetHeight;
          const visibleTop = list.scrollTop;
          const visibleBottom = visibleTop + list.clientHeight;

          if (top < visibleTop) {
            list.scrollTop = top;
          } else if (bottom > visibleBottom) {
            list.scrollTop = bottom - list.clientHeight;
          }
        }
      }

      state.pendingListScrollTop = null;
      state.pendingSubjectIndex = null;
    });
  }

  function render() {
    const root = document.getElementById("orbit-kiet-root");
    if (!root) return;

    if (state.minimized) {
      root.innerHTML = `
        <button class="orbit-minimized" id="orbit-restore" title="Open Orbit">
          <span class="orbit-minimized-dot"></span>
          <span>Orbit</span>
          <span class="orbit-minimized-arrow">↑</span>
        </button>
      `;
      root.querySelector("#orbit-restore")?.addEventListener("click", () => {
        state.minimized = false;
        localStorage.setItem("orbit-kiet-minimized", "0");
        render();
      });
      return;
    }

    root.innerHTML = `
      <section class="orbit-panel">
        <div class="orbit-header">
          <div>
            <div class="orbit-overline">ORBIT · KIET</div>
            <h2>${state.tab === "attendance" ? "Attendance" : "Timetable"}</h2>
          </div>
          <div class="orbit-actions">
            ${state.tab === "attendance" && state.data ? '<div class="orbit-live">Live</div>' : ""}
            <button id="orbit-refresh" class="orbit-refresh">${
              state.tab === "attendance"
                ? (state.loading ? "Loading…" : "Refresh")
                : (state.scheduleLoading ? "Loading…" : "Refresh")
            }</button>
            <button id="orbit-minimize" class="orbit-minimize" title="Minimize Orbit">−</button>
          </div>
        </div>

        <div class="orbit-tabs" role="tablist">
          <button class="orbit-tab ${state.tab === "attendance" ? "active" : ""}" data-tab="attendance">
            Attendance
          </button>
          <button class="orbit-tab ${state.tab === "schedule" ? "active" : ""}" data-tab="schedule">
            Timetable
          </button>
        </div>

        ${state.tab === "attendance" ? `
          ${state.error ? `<div class="orbit-error">${escapeHtml(state.error)}</div>` : ""}
          ${state.loading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading CyberVidya…</span>
            </div>
          ` : ""}

          ${!state.loading && state.data ? `
            <div class="orbit-overall">
              <div class="orbit-section-label">OVERALL ATTENDANCE</div>
              <div class="orbit-overall-row">
                <div class="orbit-big ${tone(state.data.overall)}">${state.data.overall}%</div>
                <div class="orbit-ring ${tone(state.data.overall)}"><span>${state.data.overall}%</span></div>
              </div>
              <div class="orbit-progress"><span style="width:${state.data.overall}%"></span></div>
            </div>

            <div class="orbit-subjects-header">
              <div>
                <div class="orbit-section-label">SUBJECT-WISE</div>
                <div class="orbit-subjects-title">Your subjects</div>
              </div>
              <div class="orbit-count">${state.data.subjects.length} courses</div>
            </div>

            <div class="orbit-list">
              ${state.data.subjects.length ? state.data.subjects.map((s,i)=>`
                <article class="orbit-subject ${state.expanded.has(i) ? "open":""}">
                  <div class="orbit-subject-line">
                    <button class="orbit-subject-button" data-index="${i}">
                      <span class="orbit-subject-main">
                        <span class="orbit-subject-name">${escapeHtml(s.courseName || s.courseCode || "Unnamed course")}</span>
                        <span class="orbit-subject-code">${escapeHtml(s.courseCode || "")}</span>
                      </span>
                      <span class="orbit-subject-percent ${tone(s.percentage)}">${s.percentage}%</span>
                    </button>
                    <button class="orbit-history-eye" data-history-index="${i}" title="View lecture-wise attendance" aria-label="View lecture-wise attendance">👁</button>
                  </div>
                ${(() => {
                  const plan = attendancePlan(s);
                  return `<div class="orbit-plan ${plan.kind}">${escapeHtml(plan.text)}</div>`;
                })()}
                  ${state.expanded.has(i) ? `
                    <div class="orbit-details">
                      <div><span>Present</span><strong>${s.present ?? "—"}</strong></div>
                      <div><span>Total</span><strong>${s.total ?? "—"}</strong></div>
                      <div><span>Component</span><strong>${escapeHtml(s.component || "—")}</strong></div>
                      <div><span>Faculty</span><strong>${escapeHtml(s.faculty || "—")}</strong></div>
                    </div>` : ""}
                </article>
              `).join("") : `
                <div class="orbit-empty">
                  <strong>No subject attendance found</strong>
                  <span>Refresh once CyberVidya has loaded attendance.</span>
                </div>
              `}
            </div>
          ` : ""}
        ` : `
          ${state.scheduleError ? `<div class="orbit-error">${escapeHtml(state.scheduleError)}</div>` : ""}
          ${state.scheduleLoading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading timetable…</span>
            </div>
          ` : ""}

          ${!state.scheduleLoading ? `
            <div class="orbit-schedule-summary">
              <div class="orbit-section-label">UP NEXT</div>
              <div class="orbit-subjects-title">Your next 4 days</div>
            </div>

            <div class="orbit-schedule-list">
              ${classesNextDays(state.schedule, 4).length ? classesNextDays(state.schedule, 4).map(c=>`
                <article class="orbit-class ${(() => {
                  const sameDay = c.start && dateKey(c.start) === dateKey(new Date());
                  return sameDay && c.attendanceStatus ? `marked-${c.attendanceStatus}` : "";
                })()}">
                  <div class="orbit-class-date">${escapeHtml(formatDay(c.start))}</div>
                  <div class="orbit-class-main">
                    <div class="orbit-class-topline">
                      <div class="orbit-class-time">${escapeHtml(formatTime(c.start))}${c.end ? ` – ${escapeHtml(formatTime(c.end))}` : ""}</div>
                      ${(() => {
                        const sameDay = c.start && dateKey(c.start) === dateKey(new Date());
                        if (!sameDay || !c.attendanceStatus) return "";
                        return `<span class="orbit-mark ${c.attendanceStatus}">${c.attendanceStatus === "present" ? "PRESENT" : "ABSENT"}</span>`;
                      })()}
                    </div>
                    <div class="orbit-class-title">${escapeHtml(c.title)}</div>
                    <div class="orbit-class-meta">
                      ${c.code ? `<span>${escapeHtml(c.code)}</span>` : ""}
                      ${c.room ? `<span>${escapeHtml(c.room)}</span>` : ""}
                      ${c.faculty ? `<span>${escapeHtml(c.faculty)}</span>` : ""}
                    </div>
                  </div>
                </article>
              `).join("") : `
                <div class="orbit-empty">
                  <strong>No classes in the next 4 days</strong>
                  <span>Your timetable is clear.</span>
                </div>
              `}
            </div>
          ` : ""}
        `}
      </section>

      ${state.history ? `
        <div class="orbit-modal-backdrop" id="orbit-history-backdrop">
          <section class="orbit-history-modal" role="dialog" aria-modal="true">
            <div class="orbit-history-header"><div><div class="orbit-section-label">LECTURE HISTORY</div><h3>${escapeHtml(state.history.subject.courseName || state.history.subject.courseCode || "Subject")}</h3><div class="orbit-history-summary">${state.history.subject.present ?? "—"} / ${state.history.subject.total ?? "—"} · ${state.history.subject.percentage}%</div></div><button class="orbit-history-close" id="orbit-history-close">×</button></div>
            ${state.historyLoading ? `<div class="orbit-loading compact"><div class="orbit-spinner"></div><span>Reading lecture history…</span></div>` : ""}
            ${state.historyError ? `<div class="orbit-error">${escapeHtml(state.historyError)}</div>` : ""}
            ${!state.historyLoading&&!state.historyError ? `<div class="orbit-history-table"><div class="orbit-history-row orbit-history-head"><span>Date</span><span>Day</span><span>Time</span><span>Attendance</span></div>${state.history.records.length?state.history.records.map(r=>`<div class="orbit-history-row"><span>${escapeHtml(r.date||"—")}</span><span>${escapeHtml(r.day||"—")}</span><span>${escapeHtml(r.time||"—")}</span><span class="orbit-history-status ${/PRESENT|ATTENDED/i.test(r.attendance)?"present":"absent"}">${escapeHtml(r.attendance||"UNKNOWN")}</span></div>`).join(""):`<div class="orbit-empty"><strong>No lecture records found</strong><span>CyberVidya returned no dated attendance records.</span></div>`}</div>`:""}
          </section>
        </div>
      ` : ""}
    `;

    root.querySelectorAll(".orbit-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        state.tab = tab.dataset.tab;
        render();
      });
    });

    root.querySelector("#orbit-refresh")?.addEventListener("click",
      state.tab === "attendance" ? refreshAttendance : refreshSchedule
    );

    root.querySelector("#orbit-minimize")?.addEventListener("click", () => {
      state.minimized = true;
      localStorage.setItem("orbit-kiet-minimized", "1");
      render();
    });

    root.querySelectorAll("[data-history-index]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const list = root.querySelector(".orbit-list");
        const index = Number(btn.dataset.historyIndex);

        state.pendingListScrollTop = list?.scrollTop ?? null;
        state.pendingSubjectIndex = index;

        openHistory(state.data?.subjects?.[index]);
      });
    });
    root.querySelector("#orbit-history-close")?.addEventListener("click",()=>{state.history=null;state.historyError="";state.historyLoading=false;render();});
    root.querySelector("#orbit-history-backdrop")?.addEventListener("click",e=>{if(e.target?.id==="orbit-history-backdrop"){state.history=null;state.historyError="";state.historyLoading=false;render();}});

    root.querySelectorAll(".orbit-subject-button").forEach(btn => {
      btn.addEventListener("click", () => {
        const list = root.querySelector(".orbit-list");
        const i = Number(btn.dataset.index);

        state.pendingListScrollTop = list?.scrollTop ?? null;
        state.pendingSubjectIndex = i;

        state.expanded.has(i) ? state.expanded.delete(i) : state.expanded.add(i);
        render();
      });
    });

    restoreSubjectListPosition();
  }

  async function openHistory(subject) {
    if (!subject) return;
    state.history={subject,records:[]};state.historyLoading=true;state.historyError="";render();
    try { state.history.records=await readHistoryDirectly(subject); }
    catch(error){ state.historyError=error?.message||String(error); }
    finally { state.historyLoading=false;render(); }
  }

  async function refreshAttendance() {
    state.loading = true; state.error = "";
    render();
    try {
      const response = await new Promise(resolve => chrome.runtime.sendMessage({type:"ORBIT_GET_ATTENDANCE"}, resolve));
      if (!response?.ok) throw new Error(`Attendance request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      const extracted = extractSubjects(response.data);
      const subjects = extracted.subjects;
      state.data = { overall: pageOverall() ?? weightedOverall(subjects) ?? 0, subjects, studentId: extracted.studentId, sessionId: extracted.sessionId };
      if (!subjects.length) state.error = "Attendance API returned 200, but no subjects were found.";
    } catch (e) {
      state.error = e?.message || String(e); state.data = null;
    } finally {
      state.loading = false; render();
    }
  }

  async function refreshSchedule() {
    state.scheduleLoading = true; state.scheduleError = "";
    render();
    try {
      const bounds = weekBounds(new Date());
      const response = await new Promise(resolve => chrome.runtime.sendMessage({
        type: "ORBIT_GET_SCHEDULE",
        params: { weekStartDate: bounds.start, weekEndDate: bounds.end }
      }, resolve));
      if (!response?.ok) throw new Error(`Timetable request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      state.schedule = extractSchedule(response.data);
    } catch (e) {
      state.scheduleError = e?.message || String(e);
    } finally {
      state.scheduleLoading = false; render();
    }
  }

  const root = document.createElement("div");
  root.id = "orbit-kiet-root";
  document.documentElement.appendChild(root);
  render();
  refreshAttendance();
  refreshSchedule();
})();
