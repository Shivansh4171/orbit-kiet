(() => {
  if (window.__orbitKietLoadedV11) return;
  window.__orbitKietLoadedV11 = true;

  const state = {
    tab: "attendance",
    minimized: localStorage.getItem("orbit-kiet-minimized") === "1",
    loading: false,
    scheduleLoading: false,
    error: "",
    startupNotice: "",
    scheduleError: "",
    data: null,
    schedule: [],
    scheduleSelectedDate: null,
    projectionMarks: {},
    projection: null,
    projectionDirty: false,
    expanded: new Set(),
    history: null,
    historyLoading: false,
    historyError: "",
    pendingListScrollTop: null,
    pendingScheduleListScrollTop: null,
    pendingSubjectIndex: null,
    minimizedPosition: (() => {
      try { return JSON.parse(localStorage.getItem("orbit-kiet-minimized-position") || "null"); } catch { return null; }
    })(),
    verification: new Map(),
    verificationRunning: false,
    verificationReady: false,
    verificationPreparationRunning: false,
    verificationPreparationDone: 0,
    verificationPreparationTotal: 0,
    verificationPreparationFailed: [],
    verificationCache: new Map(),
    verifiedLectureStatuses: [],
    verificationStarted: false,
  };

  const aliases = {
    code: new Set(["coursecode","subjectcode","subjectid","code","courseid"]),
    name: new Set(["coursename","coursedescription","subjectname","subject","course","name"]),
    component: new Set(["component","componentname","componenttype","coursetype","type"]),
    faculty: new Set(["faculty","facultyname","teacher","teachername","instructor"]),
    present: new Set(["present","presentcount","numberofpresent","presentlecture","presentlectures","presentperiods","classespresent","classesattended","attended","attendedclasses","attendedlectures"]),
    total: new Set(["total","totalcount","numberofperiods","totalclasses","totallecture","totallectures","totalperiods","classestotal","classesconducted","conducted","conductedclasses"]),
    presentTotal: new Set(["presenttotal","attendancetotal","lecturecount","lectures"]),
    percentage: new Set(["percentage","attendancepercentage","attendancepercent","percent","attendance","presentpercentage","presentpercentagewith"]),
    overall: new Set(["overallattendance","overallattendancepercentage","overallattendancepercent","overallpercentage","totalattendancepercentage"]),
    status: new Set(["status","attendancestatus"])
  };

  const clean = v => String(v ?? "").replace(/\s+/g, " ").trim();
  const normKey = v => clean(v).replace(/[^a-z0-9]/gi, "").toLowerCase();
  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  const get = (obj, names) => {
    for (const [k,v] of Object.entries(obj || {})) {
      if (names.has(normKey(k))) return v;
    }
  };
  const num = v => {
    const m = clean(v).match(/-?\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : undefined;
  };
  const pct = v => {
    const n = num(v);
    return n == null ? undefined : Math.max(0, Math.min(100, n));
  };

  function extractSubjects(payload) {
    const out = [], seen = new WeakSet();
    function walk(v, inherited = {code:"", name:""}) {
      if (Array.isArray(v)) return v.forEach(x => walk(x, inherited));
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const own = {
        code: clean(get(v, aliases.code)),
        name: clean(get(v, aliases.name))
      };
      const id = (own.code || own.name) ? own : inherited;
      const component = clean(get(v, aliases.component));
      const present = num(get(v, aliases.present));
      const total = num(get(v, aliases.total));
      const explicit = pct(get(v, aliases.percentage));
      const pairText = clean(get(v, aliases.presentTotal));
      const pair = pairText.match(/(\d+(?:\.\d+)?)\s*(?:\/|of)\s*(\d+(?:\.\d+)?)/i);
      const p = present ?? (pair ? Number(pair[1]) : undefined);
      const t = total ?? (pair ? Number(pair[2]) : undefined);
      const percentage = explicit ?? (p != null && t > 0 ? Math.round((p/t)*100) : undefined);

      if ((id.code || id.name) && (component || percentage != null)) {
        out.push({
          courseCode: id.code,
          courseName: id.name,
          component,
          faculty: clean(get(v, aliases.faculty)),
          present: p,
          total: t,
          percentage: percentage ?? 0,
          status: clean(get(v, aliases.status))
        });
      }
      Object.values(v).forEach(x => walk(x, id));
    }
    walk(payload);

    const uniq = new Map();
    for (const s of out) {
      const k = [s.courseCode,s.courseName,s.component,s.present,s.total,s.percentage].join("|").toLowerCase();
      if (!uniq.has(k)) uniq.set(k, s);
    }
    return [...uniq.values()];
  }

  function pageOverall() {
    const m = (document.body?.innerText || "").match(/Overall\s*Attendance[^0-9%]*(\d+(?:\.\d+)?)\s*%/i);
    return m ? pct(m[1]) : undefined;
  }
  function weightedOverall(subjects) {
    const valid = subjects.filter(s => Number.isFinite(s.present) && Number.isFinite(s.total) && s.total > 0);
    const total = valid.reduce((a,s)=>a+s.total,0);
    const present = valid.reduce((a,s)=>a+s.present,0);
    return total ? Math.round(present/total*100) : undefined;
  }

  const dateKey = d => {
    const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0"), day=String(d.getDate()).padStart(2,"0");
    return `${y}-${m}-${day}`;
  };
  const parseDate = value => {
    if (value == null) return null;
    const raw = clean(value);

    // CyberVidya currently returns values like:
    // "17/08/2026 12:30:00"
    const localMatch = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (localMatch) {
      const [, dd, mm, yyyy, hh = "0", min = "0", ss = "0"] = localMatch;
      const d = new Date(
        Number(yyyy),
        Number(mm) - 1,
        Number(dd),
        Number(hh),
        Number(min),
        Number(ss)
      );
      return Number.isNaN(d.getTime()) ? null : d;
    }

    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const formatDay = d => new Intl.DateTimeFormat(undefined, {weekday:"short", month:"short", day:"numeric"}).format(d);
  const formatTime = d => new Intl.DateTimeFormat(undefined, {hour:"numeric", minute:"2-digit"}).format(d);

  function weekBounds(base) {
    const start = new Date(base);
    start.setHours(0,0,0,0);
    start.setDate(start.getDate() - start.getDay());
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return { start: dateKey(start), end: dateKey(end) };
  }

  function extractSchedule(payload) {
    const records = [];
    const seen = new WeakSet();

    function walk(v) {
      if (Array.isArray(v)) return v.forEach(walk);
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const start = parseDate(v.start ?? v.startTime ?? v.dateTime);
      const end = parseDate(v.end ?? v.endTime);
      const type = clean(v.type).toUpperCase();
      const title = clean(v.courseName ?? v.titleFullName ?? v.title ?? v.contentFullName ?? v.content);
      const code = clean(v.courseCode);
      const faculty = clean(v.facultyName);
      const room = clean(v.classRoom ?? v.content);

      const statusRaw = clean(
        v.attendanceStatus ??
        v.attendanceState ??
        v.classAttendanceStatus ??
        v.statusText ??
        v.attendance ??
        v.presence ??
        v.attendanceMarked
      ).toLowerCase();

      const presentFlag =
        v.isPresent === true ||
        v.present === true ||
        v.markedPresent === true ||
        v.attendanceMarked === true && /present|green|attended/i.test(statusRaw);

      const absentFlag =
        v.isAbsent === true ||
        v.absent === true ||
        v.markedAbsent === true ||
        /absent|not present|red/i.test(statusRaw);

      const attendanceStatus =
        presentFlag ? "present" :
        absentFlag ? "absent" :
        /not\s+present|absent|red/i.test(statusRaw) ? "absent" :
        /present|attended|green/i.test(statusRaw) ? "present" :
        null;

      if (start && title && (type === "" || type === "CLASS" || code)) {
        records.push({
          start,
          end,
          title,
          code,
          faculty,
          room,
          variant: clean(v.courseCompVariant),
          type,
          attendanceStatus
        });
      }

      Object.values(v).forEach(walk);
    }
    walk(payload);

    const uniq = new Map();
    for (const r of records) {
      const key = [r.start.toISOString(), r.end?.toISOString() || "", r.title, r.code, r.room].join("|");
      if (!uniq.has(key)) uniq.set(key, r);
    }
    return [...uniq.values()].sort((a,b)=>a.start-b.start);
  }

  function classesNextDays(schedule, days = 4) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const end = new Date(today);
    end.setDate(end.getDate() + days - 1);
    end.setHours(23,59,59,999);
    return schedule.filter(r => r.start >= today && r.start <= end);
  }

  function scheduleDateOptions(schedule, days = 4) {
    const today = new Date();
    today.setHours(0,0,0,0);

    return Array.from({length: days}, (_, index) => {
      const date = new Date(today);
      date.setDate(today.getDate() + index);
      const key = dateKey(date);
      return {
        key,
        date,
        classes: schedule.filter(c => c.start && dateKey(c.start) === key)
          .sort((a,b) => a.start - b.start)
      };
    });
  }

  function formatScheduleDate(date) {
    return new Intl.DateTimeFormat(undefined, {
      weekday: "short",
      month: "short",
      day: "numeric"
    }).format(date);
  }

  function scheduleDateShort(date) {
    return new Intl.DateTimeFormat(undefined, {
      month: "short",
      day: "numeric"
    }).format(date);
  }

  function projectionClassKey(c) {
    return [
      historyNorm(c.code || ""),
      c.start ? c.start.getTime() : "",
      historyNorm(c.title || "")
    ].join("|");
  }

  function scheduleMatchesSubject(c, subject) {
    const cc = historyNorm(c.code || "");
    const sc = historyNorm(subject?.courseCode || "");
    if (cc && sc && cc === sc) return true;

    const ct = historyNorm(c.title || "");
    const sn = historyNorm(subject?.courseName || "");
    return !!(ct && sn && (ct === sn || ct.includes(sn) || sn.includes(ct)));
  }

  function baseAttendanceForSubject(subject, index) {
    const code = historyNorm(subject?.courseCode || "");
    const cached = code
      ? state.verificationCache.get(`code:${code}`)
      : state.verificationCache.get(index);

    const verified = state.verification.get(index)?.status === "verified";
    if (verified && cached) {
      return {
        present: Number(cached.present) || 0,
        total: Number(cached.total) || 0
      };
    }

    return {
      present: Number(subject?.present) || 0,
      total: Number(subject?.total) || 0
    };
  }

  function isOfficiallyMarkedClass(c) {
    return c?.attendanceStatus === "present" || c?.attendanceStatus === "absent";
  }

  function clearProjectionMarkForClass(c) {
    if (!c) return;
    delete state.projectionMarks[projectionClassKey(c)];
  }

  function sanitizeProjectionMarks() {
    for (const c of state.schedule || []) {
      if (isOfficiallyMarkedClass(c)) clearProjectionMarkForClass(c);
    }
  }

  function markAllForDate(dateKeyValue, value) {
    state.pendingScheduleListScrollTop = root.querySelector(".orbit-schedule-list")?.scrollTop ?? 0;
    const day = (state.schedule || []).filter(c => c.start && dateKey(c.start) === dateKeyValue);
    for (const c of day) {
      // Official CyberVidya / verified lecture-history attendance is immutable.
      if (isOfficiallyMarkedClass(c)) {
        clearProjectionMarkForClass(c);
        continue;
      }
      state.projectionMarks[projectionClassKey(c)] = value;
    }
    state.projection = null;
    state.projectionDirty = Object.keys(state.projectionMarks).length > 0;
    render();
  }

  function calculateAttendanceProjection() {
    if (!state.data?.subjects?.length) return;

    const projectedSubjects = state.data.subjects.map((subject, index) => {
      const base = baseAttendanceForSubject(subject, index);
      let present = base.present;
      let total = base.total;
      let changed = false;

      state.schedule.forEach(c => {
        if (!scheduleMatchesSubject(c, subject)) return;

        // Never allow a manual projection to overwrite an attendance status
        // that CyberVidya (or verified lecture history) has already recorded.
        if (isOfficiallyMarkedClass(c)) {
          clearProjectionMarkForClass(c);
          return;
        }

        const key = projectionClassKey(c);
        const mark = state.projectionMarks[key];
        if (!mark) return;

        total++;
        if (mark === "present") present++;
        changed = true;
      });

      const percentage = total > 0 ? Math.round((present / total) * 100) : 0;
      return { ...subject, present, total, percentage, projected: changed };
    });

    const valid = projectedSubjects.filter(s => s.total > 0);
    const total = valid.reduce((sum, s) => sum + s.total, 0);
    const present = valid.reduce((sum, s) => sum + s.present, 0);

    state.projection = {
      subjects: projectedSubjects,
      overall: total ? Math.round((present / total) * 100) : 0,
      altered: projectedSubjects.some(s => s.projected)
    };
    state.projectionDirty = false;
    render();
  }

  function tone(p) {
    if (p >= 75) return "good";
    if (p >= 65) return "warn";
    return "bad";
  }

  function attendancePlan(subject) {
    const present = Number(subject.present);
    const total = Number(subject.total);

    if (!Number.isFinite(present) || !Number.isFinite(total) || total <= 0) {
      return { kind: "unknown", text: "Attendance count unavailable" };
    }

    if (present / total >= 0.75) {
      const canMiss = Math.max(0, Math.floor((present / 0.75) - total + 1e-9));
      return {
        kind: "safe",
        text: canMiss === 1
          ? "You can miss 1 class and stay ≥75%"
          : `You can miss ${canMiss} classes and stay ≥75%`
      };
    }

    const needAttend = Math.max(0, Math.ceil(3 * total - 4 * present - 1e-9));
    return {
      kind: "need",
      text: needAttend === 1
        ? "Attend 1 more class to reach 75%"
        : `Attend ${needAttend} more classes to reach 75%`
    };
  }

  function escapeHtml(s) {
    return clean(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }


  const historySleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const historyNorm = value => String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  function findHistoryCourseRow(subject) {
    const code=historyNorm(subject?.courseCode);
    const name=historyNorm(subject?.courseName);
    const component=historyNorm(subject?.component);
    const rows=[...document.querySelectorAll('tr,[role="row"]')];
    const rowText=el=>historyNorm(el?.innerText||el?.textContent||'');

    // When CyberVidya has multiple components for the same course code,
    // matching only the code can repeatedly open the first component's history.
    // Prefer code + component, then exact code/name matches.
    if(code && component){
      const exactComponent=rows.find(el=>{
        const x=rowText(el);
        return x.includes(code) && x.includes(component);
      });
      if(exactComponent) return exactComponent;
    }
    if(code){
      const exact=rows.find(el=>rowText(el).split(/\s+/).includes(code));
      if(exact) return exact;
    }
    if(name){
      const exact=rows.find(el=>rowText(el)===name || (component && rowText(el).includes(name) && rowText(el).includes(component)));
      if(exact) return exact;
    }
    const matches=el=>{
      const x=rowText(el);
      return (code&&x.includes(code)) || (name&&x.includes(name));
    };
    const row=rows.find(matches);
    if(row) return row;
    const leaf=[...document.querySelectorAll('body *')].find(el=>el.children.length===0&&matches(el));
    return leaf?.closest('tr,[role="row"]')||null;
  }
  function findHistoryEye(row){
    if (!row) return null;

    const controls = [...row.querySelectorAll('button,[role="button"],[title],[aria-label],i,svg')];
    const score = el => {
      if (!el || !el.isConnected) return -1;
      const text = [
        el.getAttribute?.('title') || '',
        el.getAttribute?.('aria-label') || '',
        el.getAttribute?.('data-testid') || '',
        el.getAttribute?.('data-action') || '',
        el.getAttribute?.('name') || '',
        el.className?.baseVal || el.className || '',
        el.textContent || ''
      ].join(' ').toLowerCase();

      let value = 0;
      if (/\beye\b/.test(text) || /fa-eye|icon-eye|eye-icon|visibility/.test(text)) value += 100;
      if (/lecture|history|attendance|detail|view/.test(text)) value += 20;
      if (el.matches?.("svg[data-icon='eye'],svg[aria-label*='eye' i]")) value += 100;
      if (el.matches?.("i.fa-eye,i.fas.fa-eye,i.far.fa-eye")) value += 100;

      // Anchors with a real href are unsafe for automatic verification because
      // clicking them can navigate/reload CyberVidya. Only accept them if they
      // are clearly an eye control and do not have a navigable href.
      if (el.tagName === 'A' && el.getAttribute('href') && el.getAttribute('href') !== '#') return -1;
      return value;
    };

    const ranked = controls
      .map(el => ({el, score: score(el)}))
      .filter(x => x.score >= 100)
      .sort((a,b) => b.score - a.score);

    if (!ranked.length) return null;

    const candidate = ranked[0].el;
    // Prefer the actual clickable ancestor when the match is an SVG/icon.
    return candidate.closest?.('button,[role="button"]') || candidate;
  }
  function findOfficialHistoryModal(){
    const cs=[...document.querySelectorAll('[role="dialog"],.modal,[class*="modal"],[class*="dialog"]')];
    return cs.find(el=>{const x=historyNorm(el.innerText||'');return x.includes('lecture wise attendance')||x.includes('lecture-wise attendance')||(x.includes('date')&&x.includes('time slot')&&x.includes('attendance'));})||null;
  }
  function getHistoryVisualTargets(modal){
    const targets=[modal];
    let parent=modal?.parentElement;
    while(parent && parent !== document.body){
      const cls=String(parent.className?.baseVal || parent.className || '').toLowerCase();
      const role=parent.getAttribute?.('role') || '';
      if (role === 'dialog' || /backdrop|overlay|modal/.test(cls)) {
        targets.push(parent);
        if (/backdrop|overlay/.test(cls)) break;
      }
      parent=parent.parentElement;
    }
    return [...new Set(targets)];
  }

  function hideHistoryVisuals(modal){
    return getHistoryVisualTargets(modal).map(el=>{
      const state={
        el,
        visibility:el.style.visibility,
        opacity:el.style.opacity,
        pointerEvents:el.style.pointerEvents
      };
      // Do NOT use visibility:hidden or display:none here. CyberVidya's
      // lecture table can become unreadable through innerText when hidden.
      // opacity:0 keeps the live DOM/table populated while making it invisible
      // and pointer-events:none prevents it from blocking CyberVidya.
      el.style.opacity='0';
      el.style.pointerEvents='none';
      return state;
    });
  }

  function restoreHistoryVisuals(states){
    for(const s of states||[]){
      if(!s.el?.isConnected) continue;
      s.el.style.visibility=s.visibility;
      s.el.style.opacity=s.opacity;
      s.el.style.pointerEvents=s.pointerEvents;
    }
  }

  function parseOfficialHistoryModal(modal){
    const out=[];
    const rows=[
      ...modal.querySelectorAll('table tbody tr'),
      ...modal.querySelectorAll('[role="row"]')
    ];

    for(const row of rows){
      const cells=[...row.querySelectorAll('td,[role="cell"]')]
        .map(c=>String(c.textContent||'').replace(/\s+/g,' ').trim());

      if(cells.length<4) continue;

      const joined=cells.join(' ').toLowerCase();
      if(joined.includes('date') && joined.includes('attendance')) continue;

      const si=cells.findIndex(c=>/\b(present|absent)\b/i.test(c));
      if(si<0) continue;

      out.push({
        date:cells[1]||cells[0]||'',
        day:cells[2]||'',
        time:cells[3]||'',
        lectureType:cells[4]||'',
        attendance:String(cells[si]||'').toUpperCase()
      });
    }
    return out;
  }
  function closeOfficialHistoryModal(modal){
    const cs=[...(modal?.querySelectorAll('button,[role="button"],[title],[aria-label]')||[])];
    const close=cs.find(el=>{const b=[el.getAttribute?.('title')||'',el.getAttribute?.('aria-label')||'',el.textContent||'',el.className?.baseVal||el.className||''].join(' ').toLowerCase();return /close/.test(b)||String(el.textContent||'').trim()==='×';});
    try{close?.click();}catch{}
  }
  async function waitForCondition(predicate, {timeout = 8000, interval = 100} = {}) {
    const started = Date.now();
    let lastError = null;
    while (Date.now() - started < timeout) {
      try {
        const value = predicate();
        if (value) return value;
      } catch (error) {
        lastError = error;
      }
      await historySleep(interval);
    }
    if (lastError) throw lastError;
    return null;
  }

  function normalizeHistoryStatus(value) {
    const status = historyNorm(value).replace(/[.:]/g, "").trim();
    if (/^(not\s+present|absent|not\s+attended|not\s+attended\s+lecture)$/.test(status)) return "absent";
    if (/^(present|attended|attended\s+lecture)$/.test(status)) return "present";
    return null;
  }

  function historySignature(modal) {
    return parseOfficialHistoryModal(modal)
      .map(r => `${r.date}|${r.time}|${r.attendance}`)
      .join("\n");
  }

  async function readHistoryDirectly(subject){
    
    const row=findHistoryCourseRow(subject);
    
    if(!row) throw new Error(`Could not find the CyberVidya row for ${subject.courseCode||subject.courseName}.`);

    const eye=findHistoryEye(row);
    
    if(!eye) throw new Error("Could not find CyberVidya's lecture-history eye button.");
    if(!eye.isConnected) throw new Error("CyberVidya's lecture-history control became unavailable.");

    const initialUrl=location.href;
    let historyVisualState=[];
    let navigated=false;
    const markNavigation=()=>{ navigated=location.href!==initialUrl; };
    window.addEventListener('popstate',markNavigation,true);
    window.addEventListener('hashchange',markNavigation,true);

    try {
      if(eye.tagName==='A' && eye.getAttribute('href') && eye.getAttribute('href')!=='#'){
        throw new Error("CyberVidya exposed a navigational history link; verification was stopped safely.");
      }

      const stale=findOfficialHistoryModal();
      if(stale) closeOfficialHistoryModal(stale);

      
      eye.click();

      // Modal appearance should be quick. We do not spend 15s here because a
      // subject that cannot open its history must not block all remaining ones.
      const modal=await waitForCondition(
        ()=>findOfficialHistoryModal(),
        {timeout:8000,interval:100}
      );

      if(navigated) throw new Error("CyberVidya navigated away while opening lecture history.");
      if(!modal) throw new Error("CyberVidya did not open the lecture-history modal.");

      // Immediately make the CyberVidya history UI invisible/non-interactive.
      // The modal stays mounted and its table remains readable via textContent.
      historyVisualState=hideHistoryVisuals(modal);

      // The important readiness condition is NOT "some rows exist".
      // Wait until the parsed history itself contains a complete valid
      // PRESENT/ABSENT set. Then require only two consecutive equal signatures
      // 250ms apart. This avoids the old 15s + 5s fixed waiting path.
      
      const deadline=Date.now()+12000;
      let records=null;
      let previousSignature="";
      let stableCount=0;

      while(Date.now()<deadline){
        const nextRecords=parseOfficialHistoryModal(modal);
        const verified=verifiedFromRecords(nextRecords);

        if(verified){
          const signature=historySignature(modal);
          if(signature===previousSignature) stableCount++;
          else stableCount=1;

          previousSignature=signature;
          records=nextRecords;

          if(stableCount>=2) break;
        } else {
          stableCount=0;
          previousSignature="";
          records=null;
        }

        await historySleep(250);
      }

      if(!records) {
        
        throw new Error("Lecture history did not finish loading valid PRESENT/ABSENT records.");
      }

      
      closeOfficialHistoryModal(modal);
      await waitForCondition(
        ()=>!findOfficialHistoryModal(),
        {timeout:800,interval:50}
      ).catch(()=>{});

      restoreHistoryVisuals(historyVisualState);
      return records;
    } finally {
      restoreHistoryVisuals(historyVisualState);
      window.removeEventListener('popstate',markNavigation,true);
      window.removeEventListener('hashchange',markNavigation,true);
      
    }
  }

  function verifiedFromRecords(records){
    if(!Array.isArray(records) || !records.length) return null;
    let present=0, absent=0;
    for(const record of records){
      const status=normalizeHistoryStatus(record?.attendance);
      if(status === "present") present++;
      else if(status === "absent") absent++;
      else return null;
    }
    const total=present+absent;
    if(!total) return null;
    return { present, absent, total, percentage: Math.round((present/total)*100) };
  }

  function parseHistoryDateTime(dateText, timeText) {
    const rawDate = clean(dateText);
    const m = rawDate.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
    if (!m) return null;
    const d = new Date(Number(m[3]), Number(m[2]) - 1, Number(m[1]), 0, 0, 0, 0);
    const tm = clean(timeText).match(/^(\d{1,2}):(\d{2})\s*(AM|PM)\s*(?:-|–|—)\s*(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
    if (tm) {
      const h12 = Number(tm[1]) % 12;
      const startHour = h12 + (tm[3].toUpperCase() === 'PM' ? 12 : 0);
      d.setHours(startHour, Number(tm[2]), 0, 0);
    }
    return d;
  }

  const timeMinutes = d => d ? d.getHours() * 60 + d.getMinutes() : null;

  function applyVerifiedScheduleAttendance() {
    if (!Array.isArray(state.schedule) || !state.verifiedLectureStatuses.length) return;
    const now = new Date();
    state.schedule = state.schedule.map(c => {
      if (!c.start || c.start > now) return c;
      const cCode = historyNorm(c.code);
      const cTitle = historyNorm(c.title);
      const cDate = dateKey(c.start);
      const cStart = timeMinutes(c.start);
      const cEnd = timeMinutes(c.end || c.start);

      const match = state.verifiedLectureStatuses.find(v => {
        if (v.date !== cDate) return false;
        const subjectMatch = (v.code && cCode && v.code === cCode) ||
          (v.name && cTitle && (cTitle.includes(v.name) || v.name.includes(cTitle)));
        if (!subjectMatch) return false;
        if (v.start == null || cStart == null) return true;
        const startClose = Math.abs(v.start - cStart) <= 2;
        const endClose = v.end == null || cEnd == null || Math.abs(v.end - cEnd) <= 2;
        return startClose && endClose;
      });

      if (match) {
        const next = {...c, attendanceStatus: match.attendance};
        clearProjectionMarkForClass(next);
        return next;
      }
      return c;
    });
  }

  function addVerifiedLectureStatuses(subject, records) {
    for (const record of records || []) {
      const dt = parseHistoryDateTime(record.date, record.time);
      const status = normalizeHistoryStatus(record.attendance);
      if (!dt || !status) continue;
      state.verifiedLectureStatuses.push({
        code: historyNorm(subject.courseCode),
        name: historyNorm(subject.courseName),
        date: dateKey(dt),
        start: timeMinutes(dt),
        end: (() => {
          const match = clean(record.time).match(/^[^–—-]+(?:-|–|—)\s*(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
          if (!match) return null;
          let hour = Number(match[1]) % 12;
          if (match[3].toUpperCase() === 'PM') hour += 12;
          return hour * 60 + Number(match[2]);
        })(),
        attendance: status
      });
    }
  }

  async function prepareVerification(subjects) {
    if (
      state.verificationPreparationRunning ||
      state.verificationReady ||
      !Array.isArray(subjects) ||
      !subjects.length
    ) return;

    state.verificationPreparationRunning = true;
    state.verificationReady = false;
    state.verificationStarted = true;
    state.verificationPreparationDone = 0;
    state.verificationPreparationTotal = subjects.length;
    state.verificationPreparationFailed = [];
    state.verificationCache = new Map();
    state.verifiedLectureStatuses = [];
    render();

    // Let CyberVidya finish its current dashboard paint before opening the
    // first history. We wait for the real document state, not a long sleep.
    if (document.readyState !== "complete") {
      await waitForCondition(() => document.readyState === "complete", {
        timeout: 10000,
        interval: 100
      });
    }
    await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));

    for (let i = 0; i < subjects.length; i++) {
      const subject = subjects[i];
      let records = null;
      let lastError = null;

      // Each subject gets one bounded, event-based read. A problematic
      // CyberVidya history must never hold the entire preparation at 1/12.
      try {
        const records=await readHistoryDirectly(subject);
        const verified=verifiedFromRecords(records);
        if(!verified || verified.total <= 0) {
          throw new Error("Lecture history did not contain a complete PRESENT/ABSENT set.");
        }

        const prepared={
          records,
          present:verified.present,
          absent:verified.absent,
          total:verified.total,
          percentage:verified.percentage
        };
        state.verificationCache.set(i,prepared);
        const stableCode=historyNorm(subject.courseCode || subject.code || "");
        if(stableCode) state.verificationCache.set(`code:${stableCode}`,prepared);
        addVerifiedLectureStatuses(subject,records);
        
      } catch(error) {
        state.verificationPreparationFailed.push({
          index:i,
          subject,
          message:error?.message || "Could not load lecture history."
        });
      }

      state.verificationPreparationDone=i+1;
      preserveSubjectListPosition();
      render();
    }

    state.verificationPreparationRunning = false;
    state.verificationPreparedCount = new Set(
      [...state.verificationCache.keys()]
        .filter(k => typeof k === "string" && k.startsWith("code:"))
    ).size;
    // Verification can proceed with the histories that were successfully
    // prepared. Subjects that could not be prepared will be handled as
    // individual verification failures instead of blocking the whole run.
    state.verificationReady = true;
    try {
      localStorage.setItem("orbit-verify-prep-count", String(state.verificationPreparedCount || 0));
    } catch {}

    applyVerifiedScheduleAttendance();
    render();
  }

  async function verifySubjects(subjects) {
    if (
      state.verificationRunning ||
      state.verificationPreparationRunning ||
      !state.verificationReady ||
      !Array.isArray(subjects) ||
      !subjects.length
    ) return;

    state.verificationRunning = true;
    state.verification = new Map(subjects.map((_, i) => [i, { status: "verifying" }]));
    state.verifiedLectureStatuses = [];
    render();

    for (let i = 0; i < subjects.length; i++) {
      const subject = subjects[i];
      const stableCode=historyNorm(subject.courseCode || subject.code || "");
      const cached =
        (stableCode && state.verificationCache.get(`code:${stableCode}`)) ||
        state.verificationCache.get(i);

      if (!cached) {
        
        state.verification.set(i, {
          status: "failed",
          message: "Lecture history was not prepared."
        });
        continue;
      }

      subjects[i].present = cached.present;
      subjects[i].total = cached.total;
      subjects[i].percentage = cached.percentage;

      
      state.verification.set(i, {
        status: "verified",
        present: cached.present,
        absent: cached.absent
      });

      addVerifiedLectureStatuses(subject, cached.records);
      applyVerifiedScheduleAttendance();
      render();
    }

    state.data.overall = weightedOverall(subjects) ?? state.data.overall;
    applyVerifiedScheduleAttendance();
    state.verificationRunning = false;
    restoreCyberVidyaPageInteraction();
    render();
    [0,100,300,700,1200].forEach(delay => setTimeout(restoreCyberVidyaPageInteraction, delay));
  }

  function preserveSubjectListPosition(){
    const root=document.getElementById("orbit-kiet-root");
    const list=root?.querySelector(".orbit-list");
    if(list){
      state.pendingListScrollTop=list.scrollTop;
    }
  }

  function restoreSubjectListPosition() {
    if (state.pendingListScrollTop == null && state.pendingSubjectIndex == null) return;

    const targetScrollTop = state.pendingListScrollTop;
    const targetIndex = state.pendingSubjectIndex;
    const restore = () => {
      const list = document.querySelector("#orbit-kiet-root .orbit-list");
      if (!list) return;

      // Eye/history: preserve the exact scroll position.
      if (targetScrollTop != null) list.scrollTop = targetScrollTop;

      // Expand/collapse: keep the toggled subject visible as before.
      if (targetIndex != null) {
        const subject = list.querySelector(`[data-subject-index="${targetIndex}"]`);
        if (subject) {
          const top = subject.offsetTop;
          const bottom = top + subject.offsetHeight;
          const visibleTop = list.scrollTop;
          const visibleBottom = visibleTop + list.clientHeight;
          if (top < visibleTop) list.scrollTop = top;
          else if (bottom > visibleBottom) list.scrollTop = bottom - list.clientHeight;
        }
      }
    };

    requestAnimationFrame(() => {
      restore();
      requestAnimationFrame(() => {
        restore();
        setTimeout(() => {
          restore();
          // Keep the saved scroll while history is open. Once closed, consume it.
          if (!state.history) {
            state.pendingListScrollTop = null;
            state.pendingSubjectIndex = null;
          }
        }, 0);
      });
    });
  }

  function setupMinimizedDrag() {
    const root = document.getElementById("orbit-kiet-root");
    const button = root?.querySelector("#orbit-restore");
    if (!root || !button) return;

    if (state.minimizedPosition && Number.isFinite(state.minimizedPosition.left) && Number.isFinite(state.minimizedPosition.top)) {
      root.style.left = `${state.minimizedPosition.left}px`;
      root.style.top = `${state.minimizedPosition.top}px`;
      root.style.right = "auto";
    }

    let dragging = false;
    let moved = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;

    button.addEventListener("pointerdown", e => {
      dragging = true;
      moved = false;
      startX = e.clientX;
      startY = e.clientY;
      const rect = root.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      button.setPointerCapture?.(e.pointerId);
      e.preventDefault();
    });

    button.addEventListener("pointermove", e => {
      if (!dragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      if (Math.abs(dx) + Math.abs(dy) > 4) moved = true;

      const rect = root.getBoundingClientRect();
      const nextLeft = Math.max(8, Math.min(window.innerWidth - rect.width - 8, startLeft + dx));
      const nextTop = Math.max(8, Math.min(window.innerHeight - rect.height - 8, startTop + dy));
      root.style.left = `${nextLeft}px`;
      root.style.top = `${nextTop}px`;
      root.style.right = "auto";
    });

    button.addEventListener("pointerup", e => {
      if (!dragging) return;
      dragging = false;
      button.releasePointerCapture?.(e.pointerId);
      if (moved) {
        const rect = root.getBoundingClientRect();
        state.minimizedPosition = { left: Math.round(rect.left), top: Math.round(rect.top) };
        localStorage.setItem("orbit-kiet-minimized-position", JSON.stringify(state.minimizedPosition));
        button._orbitSetSuppress?.(true);
      }
    });
  }


  function restoreCyberVidyaPageInteraction(){
    const orbit=document.getElementById("orbit-kiet-root");
    const body=document.body;
    const html=document.documentElement;

    if(body){
      for(const cls of [...body.classList]){
        if(/modal-open|dialog-open|overlay-open|backdrop-open|no-scroll/i.test(cls)){
          body.classList.remove(cls);
        }
      }
      body.inert=false;
      if(body.style.pointerEvents === "none") body.style.pointerEvents="";
      if(body.style.overflow === "hidden") body.style.overflow="";
    }
    if(html){
      if(html.style.pointerEvents === "none") html.style.pointerEvents="";
      if(html.style.overflow === "hidden") html.style.overflow="";
    }

    // CyberVidya's modal/backdrop can survive after close and intercept every
    // click even though it is visually gone. Only target obvious overlay-like
    // elements outside Orbit.
    for(const el of [...document.body.querySelectorAll(
      '[class*="modal-backdrop"],[class*="backdrop"],[class*="overlay"],[role="dialog"]'
    )]){
      if(orbit?.contains(el)) continue;
      const cs=getComputedStyle(el);
      const r=el.getBoundingClientRect();
      const cls=String(el.className?.baseVal || el.className || "").toLowerCase();
      const fullScreen = cs.position==="fixed" &&
        r.width >= innerWidth*.8 && r.height >= innerHeight*.8;
      const obvious = /backdrop|overlay/.test(cls) || el.getAttribute("aria-modal")==="true";
      if(obvious || fullScreen){
        el.style.setProperty("display","none","important");
        el.style.setProperty("visibility","hidden","important");
        el.style.setProperty("opacity","0","important");
        el.style.setProperty("pointer-events","none","important");
      }
    }
  }

  function render() {
    const root = document.getElementById("orbit-kiet-root");
    if (!root) return;
    sanitizeProjectionMarks();
    state.projectionDirty = Object.keys(state.projectionMarks).length > 0 && !state.projection;

    if (state.minimized) {
      root.style.width = "auto";
      root.innerHTML = `
        <button class="orbit-minimized" id="orbit-restore" title="Open Orbit">
          <span class="orbit-minimized-dot"></span>
          <span>Orbit</span>
          <span class="orbit-minimized-arrow">↑</span>
        </button>
      `;
      const restoreButton = root.querySelector("#orbit-restore");
      if (restoreButton) {
        let suppressClick = false;
        restoreButton.addEventListener("click", () => {
          if (suppressClick) {
            suppressClick = false;
            return;
          }
          state.minimized = false;
          localStorage.setItem("orbit-kiet-minimized", "0");
          root.style.left = "";
          root.style.top = "";
          root.style.right = "";
          root.style.width = "";
          render();
        });
        restoreButton.dataset.orbitDragReady = "1";
        restoreButton._orbitSetSuppress = value => { suppressClick = value; };
      }
      setupMinimizedDrag();
      return;
    }

    root.style.width = "";
    root.style.left = "";
    root.style.top = "";
    root.style.right = "";

    root.innerHTML = `
      <section class="orbit-panel">
        <div class="orbit-header">
          <div>
            <div class="orbit-overline">ORBIT · KIET</div>
            <h2>${state.tab === "attendance" ? "" : "Timetable"}</h2>
          </div>
          <div class="orbit-actions">
            
            ${state.tab === "attendance" && state.data ? (() => {
              const disabled = state.verificationRunning || state.verificationPreparationRunning;
              const label = state.verificationRunning
                ? "Verifying…"
                : state.verificationPreparationRunning
                  ? `Preparing ${state.verificationPreparationDone}/${state.verificationPreparationTotal}…`
                  : state.verificationReady
                    ? "Verify"
                    : "Prepare";
              return `<button id="orbit-verify" class="orbit-verify-btn" ${disabled ? "disabled" : ""}>${label}</button>`;
            })() : ""}
            <button id="orbit-refresh" class="orbit-refresh">${
              state.tab === "attendance"
                ? (state.loading ? "Loading…" : "Refresh")
                : (state.scheduleLoading ? "Loading…" : "Refresh")
            }</button>
            <button id="orbit-minimize" class="orbit-minimize" title="Minimize Orbit">−</button>
          </div>
        </div>

        <div class="orbit-tabs" role="tablist">
          <button class="orbit-tab ${state.tab === "attendance" ? "active" : ""}" data-tab="attendance">
            Attendance
          </button>
          <button class="orbit-tab ${state.tab === "schedule" ? "active" : ""}" data-tab="schedule">
            Timetable
          </button>
        </div>

        ${state.tab === "attendance" ? `
          ${state.startupNotice ? `<div class="orbit-notice">${escapeHtml(state.startupNotice)}</div>` : ""}
          ${state.error ? `<div class="orbit-error">${escapeHtml(state.error)}</div>` : ""}
          ${state.loading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading CyberVidya…</span>
            </div>
          ` : ""}

          ${!state.loading && state.data ? `
            <div class="orbit-overall">
              <div class="orbit-section-label">OVERALL ATTENDANCE</div>
              ${(() => {
                const overall = state.projection?.overall ?? state.data.overall;
                const altered = !!state.projection?.altered;
                return `
                  <div class="orbit-overall-row">
                    <div class="orbit-big ${tone(overall)}">${overall}${altered ? '<sup class="orbit-altered-star" title="Projected attendance">*</sup>' : ''}%</div>
                    <div class="orbit-ring ${tone(overall)}"><span>${overall}${altered ? '<sup class="orbit-altered-star">*</sup>' : ''}%</span></div>
                  </div>
                  <div class="orbit-progress"><span style="width:${overall}%"></span></div>
                  ${altered ? '<div class="orbit-projection-note">* Projected attendance based on your manual timetable marks.</div>' : ''}
                `;
              })()}
            </div>

            <div class="orbit-subjects-header">
              <div>
                <div class="orbit-section-label">SUBJECT-WISE</div>
                <div class="orbit-subjects-title">Your subjects</div>
              </div>
              <div class="orbit-count">${state.data.subjects.length} courses</div>
            </div>

            <div class="orbit-list">
              ${state.data.subjects.length ? state.data.subjects.map((s,i)=>{
                const displaySubject = state.projection?.subjects?.[i] || s;
                const projected = !!state.projection?.altered && !!displaySubject.projected;
                return `
                <article class="orbit-subject ${state.expanded.has(i) ? "open":""}" data-subject-index="${i}">
                  <div class="orbit-subject-line">
                    <button class="orbit-subject-button" data-index="${i}">
                      <span class="orbit-subject-main">
                        <span class="orbit-subject-name">${escapeHtml(displaySubject.courseName || displaySubject.courseCode || "Unnamed course")}</span>
                        <span class="orbit-subject-code">${escapeHtml(displaySubject.courseCode || "")}</span>
                      </span>
                      <span class="orbit-subject-percent ${tone(displaySubject.percentage)}">${displaySubject.percentage}${projected ? '<sup class="orbit-altered-star" title="Projected attendance">*</sup>' : ''}%</span>
                    </button>
                    <button class="orbit-history-eye" data-history-index="${i}" title="View lecture-wise attendance" aria-label="View lecture-wise attendance">👁</button>
                  </div>
                  ${(() => {
                    const check = state.verification.get(i);
                    if (!check) return '';
                    if (check.status === 'verifying') return '<div class="orbit-verification verifying">⟳ Verifying lecture history…</div>';
                    if (check.status === 'retrying') return `<div class="orbit-verification verifying">↻ Retrying verification (${check.attempt}/3)…</div>`;
                    if (check.status === 'verified') return `<div class="orbit-verification verified">✓ Verified · ${check.present} Present · ${check.absent} Absent</div>`;
                    return '<div class="orbit-verification failed">Couldn’t verify · showing CyberVidya value</div>';
                  })()}
                ${(() => {
                  const plan = attendancePlan(displaySubject);
                  return `<div class="orbit-plan ${plan.kind}">${escapeHtml(plan.text)}</div>`;
                })()}
                  ${state.expanded.has(i) ? `
                    <div class="orbit-details">
                      <div><span>Present</span><strong>${displaySubject.present ?? "—"}</strong></div>
                      <div><span>${state.verification.get(i)?.status === 'verified' ? 'Absent' : 'Total'}</span><strong>${state.verification.get(i)?.status === 'verified' ? state.verification.get(i).absent : (displaySubject.total ?? "—")}</strong></div>
                      <div><span>Component</span><strong>${escapeHtml(s.component || "—")}</strong></div>
                      <div><span>Faculty</span><strong>${escapeHtml(s.faculty || "—")}</strong></div>
                    </div>` : ""}
                </article>
              `}).join("") : `
                <div class="orbit-empty">
                  <strong>No subject attendance found</strong>
                  <span>Refresh once CyberVidya has loaded attendance.</span>
                </div>
              `}
            </div>
          ` : ""}
        ` : `
          ${state.scheduleError ? `<div class="orbit-error">${escapeHtml(state.scheduleError)}</div>` : ""}
          ${state.scheduleLoading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading timetable…</span>
            </div>
          ` : ""}

          ${!state.scheduleLoading ? (() => {
            const dateOptions = scheduleDateOptions(state.schedule, 4);
            const selected = dateOptions.find(d => d.key === state.scheduleSelectedDate) || dateOptions[0];
            if (selected && state.scheduleSelectedDate !== selected.key) {
              state.scheduleSelectedDate = selected.key;
            }

            return `
              <div class="orbit-schedule-summary">
                <div class="orbit-section-label">TIMETABLE</div>
                <div class="orbit-subjects-title">Next 4 days</div>
              </div>

              <div class="orbit-date-strip" role="tablist" aria-label="Timetable dates">
                ${dateOptions.map((day, index) => `
                  <div
                    class="orbit-date-card ${day.key === selected?.key ? "active" : ""}"
                    role="presentation"
                  >
                    <button type="button" class="orbit-date-select" data-schedule-date="${day.key}" aria-label="View ${escapeHtml(scheduleDateShort(day.date))}">
                      <span class="orbit-date-weekday">${index === 0 ? "Today" : escapeHtml(day.date.toLocaleDateString(undefined,{weekday:"short"}))}</span>
                      <strong>${escapeHtml(scheduleDateShort(day.date))}</strong>
                      <span class="orbit-date-count">${day.classes.length} ${day.classes.length === 1 ? "class" : "classes"}</span>
                    </button>

                  </div>
                `).join("")}
              </div>

              ${selected ? `
                <div class="orbit-selected-day">
                  <div class="orbit-selected-day-head">
                    <div>
                      <div class="orbit-section-label">SELECTED DAY</div>
                      <div class="orbit-selected-day-title">${escapeHtml(formatScheduleDate(selected.date))}</div>
                    </div>
                    <div class="orbit-day-count">${selected.classes.length} ${selected.classes.length === 1 ? "class" : "classes"}</div>
                  </div>

                  <div class="orbit-selected-day-actions">
                    <span>Mark unrecorded classes:</span>
                    <button type="button" class="orbit-day-mark-btn present" data-mark-all-date="${selected.key}" data-mark-all-value="present" title="Mark all unrecorded classes on this day present">All Present</button>
                    <button type="button" class="orbit-day-mark-btn absent" data-mark-all-date="${selected.key}" data-mark-all-value="absent" title="Mark all unrecorded classes on this day absent">All Absent</button>
                  </div>

                  <div class="orbit-schedule-list">
                    ${selected.classes.length ? selected.classes.map(c => {
                      const markKey = projectionClassKey(c);
                      const manualMark = state.projectionMarks[markKey] || "";
                      return `
                      <article class="orbit-class ${manualMark ? `manual-${manualMark}` : (c.attendanceStatus ? `marked-${c.attendanceStatus}` : "")}">
                        <div class="orbit-class-date">${escapeHtml(formatDay(c.start))}</div>
                        <div class="orbit-class-main">
                          <div class="orbit-class-topline">
                            <div class="orbit-class-time">${escapeHtml(formatTime(c.start))}${c.end ? ` – ${escapeHtml(formatTime(c.end))}` : ""}</div>
                            ${c.attendanceStatus ? `<span class="orbit-mark ${c.attendanceStatus}">${c.attendanceStatus === "present" ? "PRESENT" : "ABSENT"}</span>` : ""}
                          </div>
                          <div class="orbit-class-title">${escapeHtml(c.title)}</div>
                          <div class="orbit-class-meta">
                            ${c.code ? `<span>${escapeHtml(c.code)}</span>` : ""}
                            ${c.room ? `<span>${escapeHtml(c.room)}</span>` : ""}
                            ${c.faculty ? `<span>${escapeHtml(c.faculty)}</span>` : ""}
                          </div>
                          <div class="orbit-class-mark">
                            ${isOfficiallyMarkedClass(c) ? `
                              <span class="orbit-official-lock">🔒 Official attendance — ${c.attendanceStatus === "present" ? "Present" : "Absent"}</span>
                            ` : `
                              <span>Project:</span>
                              <button type="button" class="orbit-mark-btn ${manualMark === "present" ? "active present" : ""}" data-attendance-mark="${escapeHtml(markKey)}" data-attendance-value="present">Present</button>
                              <button type="button" class="orbit-mark-btn ${manualMark === "absent" ? "active absent" : ""}" data-attendance-mark="${escapeHtml(markKey)}" data-attendance-value="absent">Absent</button>
                            `}
                          </div>
                        </div>
                      </article>`;
                    }).join("") : `
                      <div class="orbit-empty">
                        <strong>No classes on ${escapeHtml(scheduleDateShort(selected.date))}</strong>
                        <span>Your timetable is clear for this day.</span>
                      </div>
                    `}
                  </div>
                </div>

                <div class="orbit-projection-actions compact">
                  <span class="orbit-projection-label">Projection</span>
                  <button type="button" id="orbit-calculate" class="orbit-calculate-btn" ${state.projectionDirty ? "" : "disabled"}>Calculate</button>
                  <button type="button" id="orbit-clear-projection" class="orbit-clear-projection-btn" ${Object.keys(state.projectionMarks).length || state.projection ? "" : "disabled"}>Clear</button>
                </div>
              ` : ""}
            `;
          })() : ""}
        `}

      </section>

      ${state.history ? `
        <div class="orbit-modal-backdrop" id="orbit-history-backdrop">
          <section class="orbit-history-modal" role="dialog" aria-modal="true">
            <div class="orbit-history-header"><div><div class="orbit-section-label">LECTURE HISTORY</div><h3>${escapeHtml(state.history.subject.courseName || state.history.subject.courseCode || "Subject")}</h3><div class="orbit-history-summary">${state.history.subject.present ?? "—"} / ${state.history.subject.total ?? "—"} · ${state.history.subject.percentage}%</div></div><button class="orbit-history-close" id="orbit-history-close">×</button></div>
            ${state.historyLoading ? `<div class="orbit-loading compact"><div class="orbit-spinner"></div><span>Reading lecture history…</span></div>` : ""}
            ${state.historyError ? `<div class="orbit-error">${escapeHtml(state.historyError)}</div>` : ""}
            ${!state.historyLoading&&!state.historyError ? `<div class="orbit-history-table"><div class="orbit-history-row orbit-history-head"><span>Date</span><span>Day</span><span>Time</span><span>Attendance</span></div>${state.history.records.length?state.history.records.map(r=>`<div class="orbit-history-row"><span>${escapeHtml(r.date||"—")}</span><span>${escapeHtml(r.day||"—")}</span><span>${escapeHtml(r.time||"—")}</span><span class="orbit-history-status ${/PRESENT|ATTENDED/i.test(r.attendance)?"present":"absent"}">${escapeHtml(r.attendance||"UNKNOWN")}</span></div>`).join(""):`<div class="orbit-empty"><strong>No lecture records found</strong><span>CyberVidya returned no dated attendance records.</span></div>`}</div>`:""}
          </section>
        </div>
      ` : ""}


    `;

    // Restore saved timetable list position immediately after DOM rebuild.
    if (state.pendingScheduleListScrollTop != null) {
      const pendingScroll = state.pendingScheduleListScrollTop;
      const restoreNow = () => {
        const list = root.querySelector(".orbit-schedule-list");
        if (list) list.scrollTop = pendingScroll;
      };
      restoreNow();
      requestAnimationFrame(restoreNow);
      state.pendingScheduleListScrollTop = null;
    }

    // Restore saved subject-list position immediately after DOM rebuild.
    if (state.pendingListScrollTop != null) {
      const pendingScroll = state.pendingListScrollTop;
      const restoreNow = () => {
        const list = root.querySelector(".orbit-list");
        if (list) list.scrollTop = pendingScroll;
      };
      restoreNow();
      requestAnimationFrame(restoreNow);
    }

    root.querySelectorAll(".orbit-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        state.tab = tab.dataset.tab;
        render();
      });
    });

    root.querySelector("#orbit-verify")?.addEventListener("click", () => {
      if (state.verificationRunning || state.verificationPreparationRunning || !state.data?.subjects?.length) return;
      if (!state.verificationReady) {
        prepareVerification(state.data.subjects);
      } else {
        verifySubjects(state.data.subjects);
      }
    });

    root.querySelectorAll(".orbit-date-select").forEach(btn => {
      btn.addEventListener("click", () => {
        state.scheduleSelectedDate = btn.dataset.scheduleDate;
        render();
      });
    });

    root.querySelectorAll("[data-mark-all-date]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const dateValue = btn.dataset.markAllDate;
        const value = btn.dataset.markAllValue;
        if (dateValue && value) markAllForDate(dateValue, value);
      });
    });

    root.querySelectorAll("[data-attendance-mark]").forEach(btn => {
      btn.addEventListener("click", () => {
        state.pendingScheduleListScrollTop = root.querySelector(".orbit-schedule-list")?.scrollTop ?? 0;
        const key = btn.dataset.attendanceMark;
        const value = btn.dataset.attendanceValue;
        if (!key || !value) return;

        const target = (state.schedule || []).find(c => projectionClassKey(c) === key);
        if (isOfficiallyMarkedClass(target)) {
          clearProjectionMarkForClass(target);
          state.projectionDirty = Object.keys(state.projectionMarks).length > 0;
          render();
          return;
        }

        if (state.projectionMarks[key] === value) {
          delete state.projectionMarks[key];
        } else {
          state.projectionMarks[key] = value;
        }

        state.projection = null;
        state.projectionDirty = Object.keys(state.projectionMarks).length > 0;
        render();
      });
    });

    root.querySelector("#orbit-calculate")?.addEventListener("click", calculateAttendanceProjection);
    root.querySelector("#orbit-clear-projection")?.addEventListener("click", () => {
      if (!Object.keys(state.projectionMarks).length && !state.projection) return;
      state.pendingScheduleListScrollTop = root.querySelector(".orbit-schedule-list")?.scrollTop ?? 0;
      state.projectionMarks = {};
      state.projection = null;
      state.projectionDirty = false;
      render();
    });

    root.querySelector("#orbit-refresh")?.addEventListener("click",
      state.tab === "attendance" ? refreshAttendance : refreshSchedule
    );

    root.querySelector("#orbit-minimize")?.addEventListener("click", () => {
      state.minimized = true;
      localStorage.setItem("orbit-kiet-minimized", "1");
      const rect = root.getBoundingClientRect();
      state.minimizedPosition = { left: Math.round(rect.left), top: Math.round(rect.top) };
      localStorage.setItem("orbit-kiet-minimized-position", JSON.stringify(state.minimizedPosition));
      render();
    });

    root.querySelectorAll("[data-history-index]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const list = root.querySelector(".orbit-list");
        const index = Number(btn.dataset.historyIndex);

        state.pendingListScrollTop = list?.scrollTop ?? 0;
        // Do not force the clicked subject into view; preserve the exact
        // position where the user was browsing the list.
        state.pendingSubjectIndex = null;

        openHistory(state.data?.subjects?.[index]);
      });
    });
    root.querySelector("#orbit-history-close")?.addEventListener("click",()=>{state.history=null;state.historyError="";state.historyLoading=false;render();});
    root.querySelector("#orbit-history-backdrop")?.addEventListener("click",e=>{if(e.target?.id==="orbit-history-backdrop"){state.history=null;state.historyError="";state.historyLoading=false;render();}});

    root.querySelectorAll(".orbit-subject-button").forEach(btn => {
      btn.addEventListener("pointerdown", e => {
        // Prevent the browser from auto-scrolling the focused subject button into view.
        e.preventDefault();
      });
      btn.addEventListener("click", () => {
        const list = root.querySelector(".orbit-list");
        const i = Number(btn.dataset.index);

        // Preserve the exact list position. Do not auto-scroll the clicked
        // subject into view after the DOM is rebuilt.
        state.pendingListScrollTop = list?.scrollTop ?? 0;
        state.pendingSubjectIndex = null;

        state.expanded.has(i) ? state.expanded.delete(i) : state.expanded.add(i);
        btn.blur();
        render();
      });
    });

    restoreSubjectListPosition();
  }

  async function openHistory(subject) {
    if (!subject) return;
    const index = state.data?.subjects?.indexOf(subject) ?? -1;
    const cached = index >= 0 ? state.verificationCache.get(index) : null;
    state.history={subject,records:cached?.records ? [...cached.records] : []};
    state.historyLoading=!cached?.records;
    state.historyError="";
    render();
    if (cached?.records) return;
    try { state.history.records=await readHistoryDirectly(subject); }
    catch(error){ state.historyError=error?.message||String(error); }
    finally { state.historyLoading=false;render(); }
  }

  async function refreshAttendance() {
    state.verificationReady=false;
    state.verificationStarted=false;
    state.verificationPreparationRunning=false;
    state.verificationPreparationDone=0;
    state.verificationPreparationTotal=0;
    state.verificationCache=new Map();
    state.verifiedLectureStatuses=[];

    state.loading = true; state.error = ""; state.startupNotice = "";
    state.verification.clear();
    state.verifiedLectureStatuses=[];
    state.verificationReady=false;
    state.verificationPreparationRunning=false;
    state.verificationPreparationDone=0;
    state.verificationPreparationTotal=0;
    state.verificationPreparationFailed=[];
    state.verificationCache=new Map();
    render();
    try {
      const response = await new Promise(resolve => chrome.runtime.sendMessage({type:"ORBIT_GET_ATTENDANCE"}, resolve));
      if (!response?.ok) throw new Error(`Attendance request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      const subjects = extractSubjects(response.data);
      state.data = { overall: pageOverall() ?? weightedOverall(subjects) ?? 0, subjects };
      if (!subjects.length) state.error = "Attendance API returned 200, but no subjects were found.";
    } catch (e) {
      state.data = null;
      state.startupNotice = "Load dashboard to view attendance.";
    } finally {
      state.loading = false; render();
    }
  }

  async function refreshSchedule() {
    state.scheduleLoading = true; state.scheduleError = "";
    render();
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const end = new Date(today);
      end.setDate(end.getDate() + 3);
      end.setHours(23, 59, 59, 999);

      const response = await new Promise(resolve => chrome.runtime.sendMessage({
        type: "ORBIT_GET_SCHEDULE",
        params: { weekStartDate: dateKey(today), weekEndDate: dateKey(end) }
      }, resolve));
      if (!response?.ok) throw new Error(`Timetable request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      state.schedule = extractSchedule(response.data);
      sanitizeProjectionMarks();
      const validScheduleDates = new Set(scheduleDateOptions(state.schedule, 4).map(d => d.key));
      const todayKey = dateKey(new Date());
      if (!validScheduleDates.has(state.scheduleSelectedDate)) {
        state.scheduleSelectedDate = todayKey;
      }
    } catch (e) {
      state.scheduleError = e?.message || String(e);
    } finally {
      state.scheduleLoading = false; render();
    }
  }

  const root = document.createElement("div");
  root.id = "orbit-kiet-root";
  document.documentElement.appendChild(root);
  render();
  refreshAttendance();
  refreshSchedule();
})();
