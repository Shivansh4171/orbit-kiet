const ATTENDANCE_API_PATH = "/api/attendance/course/component/student";
const SCHEDULE_API_PATH = "/api/student/schedule/class";

async function fetchAttendanceFromPage(tabId) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async () => {
      const url = new URL("/api/attendance/course/component/student", location.origin).href;

      let token = "";
      try {
        const raw = localStorage.getItem("authenticationtoken");
        token = raw ? raw.replace(/^"|"$/g, "") : "";
      } catch {
        token = "";
      }

      const headers = {
        "Accept": "application/json, text/plain, */*",
        "X-Requested-With": "XMLHttpRequest"
      };

      if (token) {
        headers["Authorization"] = `GlobalEducation ${token}`;
      }

      try {
        const response = await fetch(url, {
          method: "GET",
          credentials: "include",
          headers
        });

        const text = await response.text();
        let data;
        try {
          data = JSON.parse(text);
        } catch {
          data = null;
        }

        return {
          ok: response.ok,
          status: response.status,
          data,
          textLength: text.length
        };
      } catch (error) {
        return {
          ok: false,
          status: 0,
          data: null,
          error: String(error?.message || error)
        };
      }
    }
  });

  return result;
}


async function fetchFromPage(tabId, kind, params = {}) {
  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: "MAIN",
    func: async ({ kind, params }) => {
      const path = kind === "schedule"
        ? "/api/student/schedule/class"
        : "/api/attendance/course/component/student";

      const url = new URL(path, location.origin);
      Object.entries(params || {}).forEach(([key, value]) => {
        if (value != null) url.searchParams.set(key, String(value));
      });

      let token = "";
      try {
        const raw = localStorage.getItem("authenticationtoken");
        token = raw ? raw.replace(/^"|"$/g, "") : "";
      } catch {}

      const headers = {
        "Accept": "application/json, text/plain, */*",
        "X-Requested-With": "XMLHttpRequest"
      };
      if (token) headers["Authorization"] = `GlobalEducation ${token}`;

      try {
        const response = await fetch(url.href, {
          method: "GET",
          credentials: "include",
          headers
        });
        const text = await response.text();
        let data = null;
        try { data = JSON.parse(text); } catch {}
        return {
          ok: response.ok,
          status: response.status,
          data,
          error: response.ok ? undefined : `HTTP ${response.status}`
        };
      } catch (error) {
        return {
          ok: false,
          status: 0,
          data: null,
          error: String(error?.message || error)
        };
      }
    },
    args: [{ kind, params }]
  });
  return result;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!["ORBIT_GET_ATTENDANCE", "ORBIT_GET_SCHEDULE"].includes(message?.type)) return;

  (async () => {
    if (!sender.tab?.id) throw new Error("No active CyberVidya tab.");
    const kind = message.type === "ORBIT_GET_SCHEDULE" ? "schedule" : "attendance";
    const result = await fetchFromPage(sender.tab.id, kind, message.params || {});
    sendResponse(result);
  })().catch((error) => {
    sendResponse({
      ok: false,
      status: 0,
      data: null,
      error: String(error?.message || error)
    });
  });

  return true;
});
