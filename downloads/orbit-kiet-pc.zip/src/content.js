(() => {
  if (window.__orbitKietLoadedV11) return;
  window.__orbitKietLoadedV11 = true;

  const state = {
    tab: "attendance",
    minimized: localStorage.getItem("orbit-kiet-minimized") === "1",
    loading: false,
    scheduleLoading: false,
    error: "",
    scheduleError: "",
    data: null,
    schedule: [],
    expanded: new Set(),
    history: null,
    historyLoading: false,
    historyError: "",
    pendingListScrollTop: null,
    pendingSubjectIndex: null
  };

  const aliases = {
    code: new Set(["coursecode","subjectcode","subjectid","code","courseid"]),
    name: new Set(["coursename","coursedescription","subjectname","subject","course","name"]),
    component: new Set(["component","componentname","componenttype","coursetype","type"]),
    faculty: new Set(["faculty","facultyname","teacher","teachername","instructor"]),
    present: new Set(["present","presentcount","numberofpresent","presentlecture","presentlectures","presentperiods","classespresent","classesattended","attended","attendedclasses","attendedlectures"]),
    total: new Set(["total","totalcount","numberofperiods","totalclasses","totallecture","totallectures","totalperiods","classestotal","classesconducted","conducted","conductedclasses"]),
    presentTotal: new Set(["presenttotal","attendancetotal","lecturecount","lectures"]),
    percentage: new Set(["percentage","attendancepercentage","attendancepercent","percent","attendance","presentpercentage","presentpercentagewith"]),
    overall: new Set(["overallattendance","overallattendancepercentage","overallattendancepercent","overallpercentage","totalattendancepercentage"]),
    status: new Set(["status","attendancestatus"])
  };

  const clean = v => String(v ?? "").replace(/\s+/g, " ").trim();
  const normKey = v => clean(v).replace(/[^a-z0-9]/gi, "").toLowerCase();
  const isObj = v => v && typeof v === "object" && !Array.isArray(v);
  const get = (obj, names) => {
    for (const [k,v] of Object.entries(obj || {})) {
      if (names.has(normKey(k))) return v;
    }
  };
  const num = v => {
    const m = clean(v).match(/-?\d+(?:\.\d+)?/);
    return m ? Number(m[0]) : undefined;
  };
  const pct = v => {
    const n = num(v);
    return n == null ? undefined : Math.max(0, Math.min(100, n));
  };

  function extractSubjects(payload) {
    const out = [], seen = new WeakSet();
    function walk(v, inherited = {code:"", name:""}) {
      if (Array.isArray(v)) return v.forEach(x => walk(x, inherited));
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const own = {
        code: clean(get(v, aliases.code)),
        name: clean(get(v, aliases.name))
      };
      const id = (own.code || own.name) ? own : inherited;
      const component = clean(get(v, aliases.component));
      const present = num(get(v, aliases.present));
      const total = num(get(v, aliases.total));
      const explicit = pct(get(v, aliases.percentage));
      const pairText = clean(get(v, aliases.presentTotal));
      const pair = pairText.match(/(\d+(?:\.\d+)?)\s*(?:\/|of)\s*(\d+(?:\.\d+)?)/i);
      const p = present ?? (pair ? Number(pair[1]) : undefined);
      const t = total ?? (pair ? Number(pair[2]) : undefined);
      const percentage = explicit ?? (p != null && t > 0 ? Math.round((p/t)*100) : undefined);

      if ((id.code || id.name) && (component || percentage != null)) {
        out.push({
          courseCode: id.code,
          courseName: id.name,
          component,
          faculty: clean(get(v, aliases.faculty)),
          present: p,
          total: t,
          percentage: percentage ?? 0,
          status: clean(get(v, aliases.status))
        });
      }
      Object.values(v).forEach(x => walk(x, id));
    }
    walk(payload);

    const uniq = new Map();
    for (const s of out) {
      const k = [s.courseCode,s.courseName,s.component,s.present,s.total,s.percentage].join("|").toLowerCase();
      if (!uniq.has(k)) uniq.set(k, s);
    }
    return [...uniq.values()];
  }

  function pageOverall() {
    const m = (document.body?.innerText || "").match(/Overall\s*Attendance[^0-9%]*(\d+(?:\.\d+)?)\s*%/i);
    return m ? pct(m[1]) : undefined;
  }
  function weightedOverall(subjects) {
    const valid = subjects.filter(s => Number.isFinite(s.present) && Number.isFinite(s.total) && s.total > 0);
    const total = valid.reduce((a,s)=>a+s.total,0);
    const present = valid.reduce((a,s)=>a+s.present,0);
    return total ? Math.round(present/total*100) : undefined;
  }

  const dateKey = d => {
    const y=d.getFullYear(), m=String(d.getMonth()+1).padStart(2,"0"), day=String(d.getDate()).padStart(2,"0");
    return `${y}-${m}-${day}`;
  };
  const parseDate = value => {
    if (value == null) return null;
    const raw = clean(value);

    // CyberVidya currently returns values like:
    // "17/08/2026 12:30:00"
    const localMatch = raw.match(/^(\d{2})\/(\d{2})\/(\d{4})(?:[ T](\d{1,2}):(\d{2})(?::(\d{2}))?)?$/);
    if (localMatch) {
      const [, dd, mm, yyyy, hh = "0", min = "0", ss = "0"] = localMatch;
      const d = new Date(
        Number(yyyy),
        Number(mm) - 1,
        Number(dd),
        Number(hh),
        Number(min),
        Number(ss)
      );
      return Number.isNaN(d.getTime()) ? null : d;
    }

    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? null : d;
  };
  const formatDay = d => new Intl.DateTimeFormat(undefined, {weekday:"short", month:"short", day:"numeric"}).format(d);
  const formatTime = d => new Intl.DateTimeFormat(undefined, {hour:"numeric", minute:"2-digit"}).format(d);

  function weekBounds(base) {
    const start = new Date(base);
    start.setHours(0,0,0,0);
    start.setDate(start.getDate() - start.getDay());
    const end = new Date(start);
    end.setDate(end.getDate() + 6);
    return { start: dateKey(start), end: dateKey(end) };
  }

  function extractSchedule(payload) {
    const records = [];
    const seen = new WeakSet();

    function walk(v) {
      if (Array.isArray(v)) return v.forEach(walk);
      if (!isObj(v) || seen.has(v)) return;
      seen.add(v);

      const start = parseDate(v.start ?? v.startTime ?? v.dateTime);
      const end = parseDate(v.end ?? v.endTime);
      const type = clean(v.type).toUpperCase();
      const title = clean(v.courseName ?? v.titleFullName ?? v.title ?? v.contentFullName ?? v.content);
      const code = clean(v.courseCode);
      const faculty = clean(v.facultyName);
      const room = clean(v.classRoom ?? v.content);

      const statusRaw = clean(
        v.attendanceStatus ??
        v.attendanceState ??
        v.classAttendanceStatus ??
        v.statusText ??
        v.attendance ??
        v.presence ??
        v.attendanceMarked
      ).toLowerCase();

      const presentFlag =
        v.isPresent === true ||
        v.present === true ||
        v.markedPresent === true ||
        v.attendanceMarked === true && /present|green|attended/i.test(statusRaw);

      const absentFlag =
        v.isAbsent === true ||
        v.absent === true ||
        v.markedAbsent === true ||
        /absent|not present|red/i.test(statusRaw);

      const attendanceStatus =
        presentFlag ? "present" :
        absentFlag ? "absent" :
        /present|attended|green/i.test(statusRaw) ? "present" :
        /absent|not present|red/i.test(statusRaw) ? "absent" :
        null;

      if (start && title && (type === "" || type === "CLASS" || code)) {
        records.push({
          start,
          end,
          title,
          code,
          faculty,
          room,
          variant: clean(v.courseCompVariant),
          type,
          attendanceStatus
        });
      }

      Object.values(v).forEach(walk);
    }
    walk(payload);

    const uniq = new Map();
    for (const r of records) {
      const key = [r.start.toISOString(), r.end?.toISOString() || "", r.title, r.code, r.room].join("|");
      if (!uniq.has(key)) uniq.set(key, r);
    }
    return [...uniq.values()].sort((a,b)=>a.start-b.start);
  }

  function classesNextDays(schedule, days = 4) {
    const today = new Date();
    today.setHours(0,0,0,0);
    const end = new Date(today);
    end.setDate(end.getDate() + days - 1);
    end.setHours(23,59,59,999);
    return schedule.filter(r => r.start >= today && r.start <= end);
  }

  function tone(p) {
    if (p >= 75) return "good";
    if (p >= 65) return "warn";
    return "bad";
  }

  function attendancePlan(subject) {
    const present = Number(subject.present);
    const total = Number(subject.total);

    if (!Number.isFinite(present) || !Number.isFinite(total) || total <= 0) {
      return { kind: "unknown", text: "Attendance count unavailable" };
    }

    if (present / total >= 0.75) {
      const canMiss = Math.max(0, Math.floor((present / 0.75) - total + 1e-9));
      return {
        kind: "safe",
        text: canMiss === 1
          ? "You can miss 1 class and stay ≥75%"
          : `You can miss ${canMiss} classes and stay ≥75%`
      };
    }

    const needAttend = Math.max(0, Math.ceil(3 * total - 4 * present - 1e-9));
    return {
      kind: "need",
      text: needAttend === 1
        ? "Attend 1 more class to reach 75%"
        : `Attend ${needAttend} more classes to reach 75%`
    };
  }

  function escapeHtml(s) {
    return clean(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  }


  const historySleep = ms => new Promise(resolve => setTimeout(resolve, ms));
  const historyNorm = value => String(value || "").replace(/\s+/g, " ").trim().toLowerCase();
  function findHistoryCourseRow(subject) {
    const code=historyNorm(subject?.courseCode), name=historyNorm(subject?.courseName);
    const matches=el=>{const x=historyNorm(el?.innerText||el?.textContent||"");return (code&&x.includes(code))||(name&&x.includes(name));};
    const rows=[...document.querySelectorAll('tr,[role="row"]')];
    let row=rows.find(matches); if(row) return row;
    const leaf=[...document.querySelectorAll('body *')].find(el=>el.children.length===0&&matches(el));
    return leaf?.closest('tr,[role="row"],div')||null;
  }
  function findHistoryEye(row){
    const controls=[...row.querySelectorAll('button,a,[role="button"],[title],[aria-label],i,svg')];
    return controls.find(el=>{const b=[el.getAttribute?.('title')||'',el.getAttribute?.('aria-label')||'',el.className?.baseVal||el.className||'',el.textContent||''].join(' ').toLowerCase();return /eye|view|detail|attendance/.test(b)||el.matches?.("i.fa-eye,i.fas.fa-eye,i.far.fa-eye,svg[data-icon='eye']");})||controls[controls.length-1]||null;
  }
  function findOfficialHistoryModal(){
    const cs=[...document.querySelectorAll('[role="dialog"],.modal,[class*="modal"],[class*="dialog"]')];
    return cs.find(el=>{const x=historyNorm(el.innerText||'');return x.includes('lecture wise attendance')||x.includes('lecture-wise attendance')||(x.includes('date')&&x.includes('time slot')&&x.includes('attendance'));})||null;
  }
  function parseOfficialHistoryModal(modal){
    const out=[]; const rows=[...modal.querySelectorAll('table tbody tr'),...modal.querySelectorAll('[role="row"]')];
    for(const row of rows){const cells=[...row.querySelectorAll('td,[role="cell"]')].map(c=>String(c.innerText||'').replace(/\s+/g,' ').trim()); if(cells.length<4) continue; const joined=cells.join(' ').toLowerCase(); if(joined.includes('date')&&joined.includes('attendance')) continue; const si=cells.findIndex(c=>/present|absent/i.test(c)); if(si<0) continue; out.push({date:cells[1]||cells[0]||'',day:cells[2]||'',time:cells[3]||'',lectureType:cells[4]||'',attendance:String(cells[si]||'').toUpperCase()});}
    return out;
  }
  function closeOfficialHistoryModal(modal){
    const cs=[...(modal?.querySelectorAll('button,[role="button"],[title],[aria-label]')||[])];
    const close=cs.find(el=>{const b=[el.getAttribute?.('title')||'',el.getAttribute?.('aria-label')||'',el.textContent||'',el.className?.baseVal||el.className||''].join(' ').toLowerCase();return /close/.test(b)||String(el.textContent||'').trim()==='×';});
    try{close?.click();}catch{}
  }
  async function readHistoryDirectly(subject){
    const root=document.getElementById('orbit-kiet-root'); if(root) root.style.display='none';
    try{
      const row=findHistoryCourseRow(subject); if(!row) throw new Error(`Could not find the CyberVidya row for ${subject.courseCode||subject.courseName}.`);
      const eye=findHistoryEye(row); if(!eye) throw new Error("Could not find CyberVidya's lecture-history eye button.");
      eye.click(); let modal=null;
      for(let i=0;i<50;i++){await historySleep(200);modal=findOfficialHistoryModal();if(modal)break;}
      if(!modal) throw new Error('CyberVidya did not open the lecture-history modal.');
      await historySleep(200); let records=parseOfficialHistoryModal(modal); if(!records.length){await historySleep(500);records=parseOfficialHistoryModal(modal);} closeOfficialHistoryModal(modal); return records;
    } finally {if(root) root.style.display='';}
  }
  function restoreSubjectListPosition() {
    if (state.pendingListScrollTop == null && state.pendingSubjectIndex == null) return;

    requestAnimationFrame(() => {
      const list = document.querySelector("#orbit-kiet-root .orbit-list");
      if (!list) {
        state.pendingListScrollTop = null;
        state.pendingSubjectIndex = null;
        return;
      }

      if (state.pendingListScrollTop != null) {
        list.scrollTop = state.pendingListScrollTop;
      }

      if (state.pendingSubjectIndex != null) {
        const subject = list.querySelector(
          `[data-subject-index="${state.pendingSubjectIndex}"]`
        );

        if (subject) {
          const top = subject.offsetTop;
          const bottom = top + subject.offsetHeight;
          const visibleTop = list.scrollTop;
          const visibleBottom = visibleTop + list.clientHeight;

          if (top < visibleTop) {
            list.scrollTop = top;
          } else if (bottom > visibleBottom) {
            list.scrollTop = bottom - list.clientHeight;
          }
        }
      }

      state.pendingListScrollTop = null;
      state.pendingSubjectIndex = null;
    });
  }

  function render() {
    const root = document.getElementById("orbit-kiet-root");
    if (!root) return;

    if (state.minimized) {
      root.innerHTML = `
        <button class="orbit-minimized" id="orbit-restore" title="Open Orbit">
          <span class="orbit-minimized-dot"></span>
          <span>Orbit</span>
          <span class="orbit-minimized-arrow">↑</span>
        </button>
      `;
      root.querySelector("#orbit-restore")?.addEventListener("click", () => {
        state.minimized = false;
        localStorage.setItem("orbit-kiet-minimized", "0");
        render();
      });
      return;
    }

    root.innerHTML = `
      <section class="orbit-panel">
        <div class="orbit-header">
          <div>
            <div class="orbit-overline">ORBIT · KIET</div>
            <h2>${state.tab === "attendance" ? "Attendance" : "Timetable"}</h2>
          </div>
          <div class="orbit-actions">
            ${state.tab === "attendance" && state.data ? '<div class="orbit-live">Live</div>' : ""}
            <button id="orbit-refresh" class="orbit-refresh">${
              state.tab === "attendance"
                ? (state.loading ? "Loading…" : "Refresh")
                : (state.scheduleLoading ? "Loading…" : "Refresh")
            }</button>
            <button id="orbit-minimize" class="orbit-minimize" title="Minimize Orbit">−</button>
          </div>
        </div>

        <div class="orbit-tabs" role="tablist">
          <button class="orbit-tab ${state.tab === "attendance" ? "active" : ""}" data-tab="attendance">
            Attendance
          </button>
          <button class="orbit-tab ${state.tab === "schedule" ? "active" : ""}" data-tab="schedule">
            Timetable
          </button>
        </div>

        ${state.tab === "attendance" ? `
          ${state.error ? `<div class="orbit-error">${escapeHtml(state.error)}</div>` : ""}
          ${state.loading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading CyberVidya…</span>
            </div>
          ` : ""}

          ${!state.loading && state.data ? `
            <div class="orbit-overall">
              <div class="orbit-section-label">OVERALL ATTENDANCE</div>
              <div class="orbit-overall-row">
                <div class="orbit-big ${tone(state.data.overall)}">${state.data.overall}%</div>
                <div class="orbit-ring ${tone(state.data.overall)}"><span>${state.data.overall}%</span></div>
              </div>
              <div class="orbit-progress"><span style="width:${state.data.overall}%"></span></div>
            </div>

            <div class="orbit-subjects-header">
              <div>
                <div class="orbit-section-label">SUBJECT-WISE</div>
                <div class="orbit-subjects-title">Your subjects</div>
              </div>
              <div class="orbit-count">${state.data.subjects.length} courses</div>
            </div>

            <div class="orbit-list">
              ${state.data.subjects.length ? state.data.subjects.map((s,i)=>`
                <article class="orbit-subject ${state.expanded.has(i) ? "open":""}">
                  <div class="orbit-subject-line">
                    <button class="orbit-subject-button" data-index="${i}">
                      <span class="orbit-subject-main">
                        <span class="orbit-subject-name">${escapeHtml(s.courseName || s.courseCode || "Unnamed course")}</span>
                        <span class="orbit-subject-code">${escapeHtml(s.courseCode || "")}</span>
                      </span>
                      <span class="orbit-subject-percent ${tone(s.percentage)}">${s.percentage}%</span>
                    </button>
                    <button class="orbit-history-eye" data-history-index="${i}" title="View lecture-wise attendance" aria-label="View lecture-wise attendance">👁</button>
                  </div>
                ${(() => {
                  const plan = attendancePlan(s);
                  return `<div class="orbit-plan ${plan.kind}">${escapeHtml(plan.text)}</div>`;
                })()}
                  ${state.expanded.has(i) ? `
                    <div class="orbit-details">
                      <div><span>Present</span><strong>${s.present ?? "—"}</strong></div>
                      <div><span>Total</span><strong>${s.total ?? "—"}</strong></div>
                      <div><span>Component</span><strong>${escapeHtml(s.component || "—")}</strong></div>
                      <div><span>Faculty</span><strong>${escapeHtml(s.faculty || "—")}</strong></div>
                    </div>` : ""}
                </article>
              `).join("") : `
                <div class="orbit-empty">
                  <strong>No subject attendance found</strong>
                  <span>Refresh once CyberVidya has loaded attendance.</span>
                </div>
              `}
            </div>
          ` : ""}
        ` : `
          ${state.scheduleError ? `<div class="orbit-error">${escapeHtml(state.scheduleError)}</div>` : ""}
          ${state.scheduleLoading ? `
            <div class="orbit-loading">
              <div class="orbit-spinner"></div>
              <span>Reading timetable…</span>
            </div>
          ` : ""}

          ${!state.scheduleLoading ? `
            <div class="orbit-schedule-summary">
              <div class="orbit-section-label">UP NEXT</div>
              <div class="orbit-subjects-title">Your next 4 days</div>
            </div>

            <div class="orbit-schedule-list">
              ${classesNextDays(state.schedule, 4).length ? classesNextDays(state.schedule, 4).map(c=>`
                <article class="orbit-class ${(() => {
                  const sameDay = c.start && dateKey(c.start) === dateKey(new Date());
                  return sameDay && c.attendanceStatus ? `marked-${c.attendanceStatus}` : "";
                })()}">
                  <div class="orbit-class-date">${escapeHtml(formatDay(c.start))}</div>
                  <div class="orbit-class-main">
                    <div class="orbit-class-topline">
                      <div class="orbit-class-time">${escapeHtml(formatTime(c.start))}${c.end ? ` – ${escapeHtml(formatTime(c.end))}` : ""}</div>
                      ${(() => {
                        const sameDay = c.start && dateKey(c.start) === dateKey(new Date());
                        if (!sameDay || !c.attendanceStatus) return "";
                        return `<span class="orbit-mark ${c.attendanceStatus}">${c.attendanceStatus === "present" ? "PRESENT" : "ABSENT"}</span>`;
                      })()}
                    </div>
                    <div class="orbit-class-title">${escapeHtml(c.title)}</div>
                    <div class="orbit-class-meta">
                      ${c.code ? `<span>${escapeHtml(c.code)}</span>` : ""}
                      ${c.room ? `<span>${escapeHtml(c.room)}</span>` : ""}
                      ${c.faculty ? `<span>${escapeHtml(c.faculty)}</span>` : ""}
                    </div>
                  </div>
                </article>
              `).join("") : `
                <div class="orbit-empty">
                  <strong>No classes in the next 4 days</strong>
                  <span>Your timetable is clear.</span>
                </div>
              `}
            </div>
          ` : ""}
        `}
      </section>

      ${state.history ? `
        <div class="orbit-modal-backdrop" id="orbit-history-backdrop">
          <section class="orbit-history-modal" role="dialog" aria-modal="true">
            <div class="orbit-history-header"><div><div class="orbit-section-label">LECTURE HISTORY</div><h3>${escapeHtml(state.history.subject.courseName || state.history.subject.courseCode || "Subject")}</h3><div class="orbit-history-summary">${state.history.subject.present ?? "—"} / ${state.history.subject.total ?? "—"} · ${state.history.subject.percentage}%</div></div><button class="orbit-history-close" id="orbit-history-close">×</button></div>
            ${state.historyLoading ? `<div class="orbit-loading compact"><div class="orbit-spinner"></div><span>Reading lecture history…</span></div>` : ""}
            ${state.historyError ? `<div class="orbit-error">${escapeHtml(state.historyError)}</div>` : ""}
            ${!state.historyLoading&&!state.historyError ? `<div class="orbit-history-table"><div class="orbit-history-row orbit-history-head"><span>Date</span><span>Day</span><span>Time</span><span>Attendance</span></div>${state.history.records.length?state.history.records.map(r=>`<div class="orbit-history-row"><span>${escapeHtml(r.date||"—")}</span><span>${escapeHtml(r.day||"—")}</span><span>${escapeHtml(r.time||"—")}</span><span class="orbit-history-status ${/PRESENT|ATTENDED/i.test(r.attendance)?"present":"absent"}">${escapeHtml(r.attendance||"UNKNOWN")}</span></div>`).join(""):`<div class="orbit-empty"><strong>No lecture records found</strong><span>CyberVidya returned no dated attendance records.</span></div>`}</div>`:""}
          </section>
        </div>
      ` : ""}
    `;

    root.querySelectorAll(".orbit-tab").forEach(tab => {
      tab.addEventListener("click", () => {
        state.tab = tab.dataset.tab;
        render();
      });
    });

    root.querySelector("#orbit-refresh")?.addEventListener("click",
      state.tab === "attendance" ? refreshAttendance : refreshSchedule
    );

    root.querySelector("#orbit-minimize")?.addEventListener("click", () => {
      state.minimized = true;
      localStorage.setItem("orbit-kiet-minimized", "1");
      render();
    });

    root.querySelectorAll("[data-history-index]").forEach(btn => {
      btn.addEventListener("click", e => {
        e.stopPropagation();
        const list = root.querySelector(".orbit-list");
        const index = Number(btn.dataset.historyIndex);

        state.pendingListScrollTop = list?.scrollTop ?? null;
        state.pendingSubjectIndex = index;

        openHistory(state.data?.subjects?.[index]);
      });
    });
    root.querySelector("#orbit-history-close")?.addEventListener("click",()=>{state.history=null;state.historyError="";state.historyLoading=false;render();});
    root.querySelector("#orbit-history-backdrop")?.addEventListener("click",e=>{if(e.target?.id==="orbit-history-backdrop"){state.history=null;state.historyError="";state.historyLoading=false;render();}});

    root.querySelectorAll(".orbit-subject-button").forEach(btn => {
      btn.addEventListener("click", () => {
        const list = root.querySelector(".orbit-list");
        const i = Number(btn.dataset.index);

        state.pendingListScrollTop = list?.scrollTop ?? null;
        state.pendingSubjectIndex = i;

        state.expanded.has(i) ? state.expanded.delete(i) : state.expanded.add(i);
        render();
      });
    });

    restoreSubjectListPosition();
  }

  async function openHistory(subject) {
    if (!subject) return;
    state.history={subject,records:[]};state.historyLoading=true;state.historyError="";render();
    try { state.history.records=await readHistoryDirectly(subject); }
    catch(error){ state.historyError=error?.message||String(error); }
    finally { state.historyLoading=false;render(); }
  }

  async function refreshAttendance() {
    state.loading = true; state.error = "";
    render();
    try {
      const response = await new Promise(resolve => chrome.runtime.sendMessage({type:"ORBIT_GET_ATTENDANCE"}, resolve));
      if (!response?.ok) throw new Error(`Attendance request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      const subjects = extractSubjects(response.data);
      state.data = { overall: pageOverall() ?? weightedOverall(subjects) ?? 0, subjects };
      if (!subjects.length) state.error = "Attendance API returned 200, but no subjects were found.";
    } catch (e) {
      state.error = e?.message || String(e); state.data = null;
    } finally {
      state.loading = false; render();
    }
  }

  async function refreshSchedule() {
    state.scheduleLoading = true; state.scheduleError = "";
    render();
    try {
      const bounds = weekBounds(new Date());
      const response = await new Promise(resolve => chrome.runtime.sendMessage({
        type: "ORBIT_GET_SCHEDULE",
        params: { weekStartDate: bounds.start, weekEndDate: bounds.end }
      }, resolve));
      if (!response?.ok) throw new Error(`Timetable request failed (${response?.status ?? 0})${response?.error ? `: ${response.error}` : "."}`);
      state.schedule = extractSchedule(response.data);
    } catch (e) {
      state.scheduleError = e?.message || String(e);
    } finally {
      state.scheduleLoading = false; render();
    }
  }

  const root = document.createElement("div");
  root.id = "orbit-kiet-root";
  document.documentElement.appendChild(root);
  render();
  refreshAttendance();
  refreshSchedule();
})();
