# Orbit for KIET

A Manifest V3 browser extension that adds a cleaner attendance dashboard to the official KIET CyberVidya site.

## Features

- Uses the user's existing CyberVidya login/session.
- Does not automate username/password or OTP.
- Calls the currently observed attendance endpoint:
  `/api/attendance/course/component/student`
- Shows overall attendance.
- Shows expandable subject-wise attendance.
- Parses the nested CyberVidya attendance response shape.
- No backend, database, Playwright server, or separate login app required.

## Install in Brave/Chrome

1. Extract this folder.
2. Open `brave://extensions` or `chrome://extensions`.
3. Enable Developer mode.
4. Click Load unpacked.
5. Select this folder.
6. Log into the official CyberVidya portal normally.
7. Open the dashboard or attendance page.

The extension only runs on `https://kiet.cybervidya.net/*`.

## Notes

Authentication tokens are read only in the authenticated page context and are not written to storage, logged, or sent to any third-party server.


## Timetable

The extension also reads the current week's CyberVidya schedule endpoint:

`GET /api/student/schedule/class?weekStartDate=YYYY-MM-DD&weekEndDate=YYYY-MM-DD`

It displays classes from the next 4 calendar days and shows time, course, code, room and faculty when available.


## v1.2 UI changes

- Added Attendance and Timetable tabs.
- Fixed CyberVidya schedule parsing for `dd/MM/yyyy HH:mm:ss` timestamps.


## v1.2.1

Fixed the date-parser JavaScript syntax error from v1.2.


## v1.3 UI polish

- Attendance subject list is now independently scrollable.
- Header, tabs, and overall-attendance section stay fixed while subjects scroll.
- Timetable list remains independently scrollable.
- Desktop panel sizing is cleaner at 100% browser zoom.


## v1.4 attendance planning

Each subject now shows a 75% planning hint:
- At or above 75%: how many future classes can be missed while staying at or above 75%.
- Below 75%: the minimum number of consecutive classes that must be attended to reach 75%.

The calculation uses the real present/total counts returned by CyberVidya.


## v1.5 theme + today's class status

- Light/high-contrast theme for better 100% zoom readability.
- Today's timetable classes are marked green/red when the live schedule payload exposes a present/absent status.
- Unmarked classes retain the normal card style.

Note: the extension does not invent attendance status. If CyberVidya's schedule response does not include per-class status for a class, it remains unmarked.


## v1.5.1 minimize control

Use the `−` button in the Orbit header to collapse the panel into a small floating Orbit pill. Click the pill to restore the panel. Minimized state is remembered for the current CyberVidya origin.


## v1.8 direct history
Orbit hides itself temporarily, clicks CyberVidya's real eye control, reads the official rendered lecture-history modal, closes it, and restores Orbit.


## v1.8.1 known-good history + scroll fix

Based on the known-good v1.8 lecture-history implementation. Only the subject-list
scroll-position preservation fix was carried forward. No later history-parser changes
are included.


## Eye-button scroll preservation

Opening lecture history now records the current subject-list scroll position and restores it when the history view closes.
