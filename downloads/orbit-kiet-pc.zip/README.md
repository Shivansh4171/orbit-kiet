# Orbit Premium — v18 Projection Controls

Based on the v17 benchmark.

Changes in v18:
- Day-level All Present / All Absent controls moved below the selected date.
- Officially recorded lectures remain locked.
- Timetable scroll position is preserved when marking individual lectures or an entire day.
- Added Clear projection to remove all manual projected marks and restore official/base attendance without refreshing the extension.
- Extension name/version: Orbit Premium — v18 Projection Controls / 1.0.21.

## v19 UI polish
- Calculate button now says only `Calculate` and remains green.
- Clear button now says `Clear`, sits directly beside Calculate, and is red.

- Projection controls are now a single compact line: Projection [Calculate] [Clear].

- Projection row aligned with the label at the extreme left and Calculate/Clear grouped at the extreme right.


## v1.0.18 — Verification + Projection
- Restores the Prepare → Verify workflow from the stable v21 benchmark.
- Preparation is user-triggered rather than starting automatically.
- Verify becomes available after preparation.
- Verified attendance is used for projections when available.
- Officially recorded lectures remain protected from projection.
- Retains datewise timetable and projection controls.


## v1.0.19 — UI alignment
- Projection label is fixed to the extreme left.
- Calculate and Clear are grouped on the extreme right.
- GitHub and FAQ footer cards share equal width and stay aligned.
- Removed the extra Live/annotation header status text.

## v1.0.20 — mobile header/footer
- Removed the Live label from the header.
- Moved minimize to the top-right corner of the Orbit panel.
- Compact footer: GitHub left, FAQ right.
- Removed extra footer descriptions/arrows.
